#include <stdio.h>
#include <string.h>

static int checkPassword(const char *pass) {
	int i;
	char msg[8] = { 0x47, 0x5b, 0x00, 0x43, 0x07, 0x40, 0x40, 0x33 };
	for (i = 0; i < sizeof(msg); i++) {
		msg[i] ^= 0x33;
	}
	return !strcmp (pass, msg);
}

int main() {
	char pass[128];
	printf ("Enter Password: ");
	fflush (stdout);
	fgets (pass, sizeof (pass) - 1, stdin);
	if(!feof(stdin) && *pass) {
		pass[strlen (pass) - 1] = 0;
		if (checkPassword (pass)) {
			printf ("You Won!\n");
			return 0;
		}
	}
	printf ("Sad End\n");
	return 1;
}
