#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv) {
	int i;

	for (i = 0; i < 10; i++) {
		puts ("ROOTED!");
		sleep (1);
	}

	return 0;
}
