import r2pipe

r2 = r2pipe.open("/bin/ls")
info = r2.cmdj("ij")
print ("BIN INFO")
print(info['bin'])
print ("IMPORTS")
for a in r2.cmdj('iij'):
	print "  " + a['name']
print ("LIBRARIES")
for l in r2.cmdj('ilj'):
	print "  " + l

print ("SYMBOLS")
for s in r2.cmdj('isj'):
	print "\n" + s['name'] + ":"
	for c in r2.cmdj("pdj 10 @ " + str(s['vaddr'])):
		try:
			print "   " + c['opcode']
		except:
			# print c
			pass
