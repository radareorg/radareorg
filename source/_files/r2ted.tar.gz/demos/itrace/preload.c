#include <dlfcn.h>
#include <stdio.h>

#ifndef RTLD_NEXT
#define RTLD_NEXT ((void *)-1)
#endif

int sleep(unsigned int seconds, unsigned int addr, unsigned int imp) {
	static int (*__realsleep)(unsigned int seconds) = NULL;
	__realsleep = dlsym (RTLD_NEXT, "sleep");

	if (seconds == 0x1337) {
		printf ("Fake sleep call from import 0x%x @ 0x%x\n", imp, addr);
		return 0;
	}
	return __realsleep (seconds);
}
