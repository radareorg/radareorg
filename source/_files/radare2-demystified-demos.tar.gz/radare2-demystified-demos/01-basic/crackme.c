#include <stdio.h>
#include <string.h>

int main() {
	char pass[128];
	printf ("Enter Password: ");
	fflush (stdout);
	fgets (pass, sizeof (pass) - 1, stdin);
	if(!feof(stdin) && *pass) {
		pass[strlen (pass) - 1] = 0;
		if (!strcmp ("h4rdl3v3l", pass)) {
			printf ("You Won!\n");
			return 0;
		}
	}
	printf ("Sad End\n");
	return 1;
}
