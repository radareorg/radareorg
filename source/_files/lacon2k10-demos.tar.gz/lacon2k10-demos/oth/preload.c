#include <dlfcn.h>
#include <stdio.h>

#ifndef RTLD_NEXT
#define RTLD_NEXT ((void *)-1)
#endif

int sleep(unsigned int seconds) {
	static int (*__realsleep)(unsigned int seconds) = NULL;
	__realsleep = dlsym (RTLD_NEXT, "sleep");

	if (seconds == 0x1337) {
		printf ("Hooked call\n");
		return 0;
	}
	printf ("Direct call\n");
	return __realsleep (seconds);
}
