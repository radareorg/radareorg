python md380_fw.py --unwrap /tmp/fw.bin /tmp/newfw.bin

nice function to read:

	0x800f4a6
