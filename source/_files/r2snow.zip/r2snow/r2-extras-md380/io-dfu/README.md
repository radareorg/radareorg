Python IO Plugin to talk to DFU things
======================================

Dont expect this to work. that's just a WIP PoC, i dont have the hardware to test

	$ r2 -I r2-dfu-io.py dfu://0483:df11
