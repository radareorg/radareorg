#include <stdio.h>

int foo[] = { 1,2,3,4,5,6,7,7,8,9,0, };

int trash5(int argc, char **argv)
{
	if (argc>1 && !strcmp(argv[1], "1234")) 
		printf("Correct password!\n");
	else printf("Give me a password\n");
	return foo[argc];
}
int trash4(int argc, char **argv)
{
	if (argc>1 && !strcmp(argv[1], "1234")) 
		printf("Correct password!\n");
	else printf("Give me a password\n");
	return foo[argc];
}
int trash3(int argc, char **argv)
{
	if (argc>1 && !strcmp(argv[1], "1234")) 
		printf("Correct password!\n");
	else printf("Give me a password\n");
	return foo[argc];
}
int trash2(int argc, char **argv)
{
	if (argc>1 && !strcmp(argv[1], "1234")) 
		printf("Correct password!\n");
	else printf("Give me a password\n");
	return foo[argc];
}
int trash(int argc, char **argv)
{
	if (argc>1 && !strcmp(argv[1], "1234")) 
		printf("Correct password!\n");
	else printf("Give me a password\n");
	return foo[argc];
}

struct ptr {
	int (*foofun)(int, char **);
};

struct ptr foofun[] = {
	&trash,
	&trash2,
	&trash3,
	&trash4,
	&trash5,
};

int main(int argc, char **argv)
{
	return foofun[argc].foofun(argc, argv);
	if (argc>1 && !strcmp(argv[1], "1234")) 
		printf("Correct password!\n");
	else printf("Give me a password\n");
	return foo[argc];
}

#include "/home/pancake/prg/radare/src/socket.c"
