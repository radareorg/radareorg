#!/usr/bin/python

from libr import *
import sys

a = RAsm ()
a.use ("x86.olly")
a.set_bits (32)
a.set_pc (0)

while (True):
	try:
		asm = sys.stdin.readline ()
		if (asm == "q\n"):
			break
		print a.massemble(asm).buf_hex
	except:
		print "Invalid"
