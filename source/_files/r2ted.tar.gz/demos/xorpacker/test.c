#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
	if (argc > 1 && !strncmp (argv[1], "passw0rd", 9))
		printf ("ROOTED!\n");
	else printf ("Ooops\n");

	return 0;
}
