#!/bin/sh
if [ -z "$1" ]; then
	echo "jailbreak tyt bootloader"
else
	r2 -nw -c 'wx aa @ 0x080044a8' $1
fi
