radare2 Telegram Bot
====================

This directory contains the sourcecode of the Telegram bot
for radare2. The code can be easily modified to make any
other bot for your own needs. But i'm just too lazy to split
up the core functionality into a separate node module right
now. I'll probably do someday if i have time :-)

As always, just run `npm install` to get all the dependencies
installed (actually, it's just r2pipe)

	$ npm install

To run the bot you'll need to create a file named `TOKEN`
with the Token provided by @botfather and type:

	$ npm run bot

Enjoy!
