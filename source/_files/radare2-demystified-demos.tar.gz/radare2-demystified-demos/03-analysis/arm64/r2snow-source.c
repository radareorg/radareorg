
struct s0 {
    struct s0* f0;
    unsigned char f1;
    unsigned char f2;
    signed char[5] pad8;
    struct s0* f8;
    signed char[7] pad16;
    struct s0* f16;
    signed char[7] pad24;
    struct s0* f24;
    signed char[7] pad32;
    struct s0* f32;
    signed char[7] pad40;
    struct s0* f40;
    signed char[7] pad48;
    int32_t f48;
    unsigned char f52;
};

int64_t _humanize_number = 0x1000045f8;

void _humanize_number(void* rdi, int64_t rsi, struct s0* rdx, int64_t rcx, int64_t r8, int64_t r9, int64_t a7) {
    goto _humanize_number;
}

int64_t* ___stderrp = reinterpret_cast<int64_t*>(0);

void _fwrite(int64_t rdi, struct s0* rsi, struct s0* rdx, int64_t rcx);

void _exit();

void fun_1000043f1(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    int64_t* rax4;
    int64_t rcx5;

    rax4 = ___stderrp;
    rcx5 = *rax4;
    _fwrite("usage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1] [file ...]\n", 62, 1, rcx5);
    _exit();
}

int64_t _setlocale = 0x100004846;

void _setlocale() {
    goto _setlocale;
}

int64_t _isatty = 0x1000047b0;

int32_t _isatty(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    goto _isatty;
}

int64_t _getenv = 0x10000476a;

struct s0* _getenv(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    goto _getenv;
}

int64_t _atoi = 0x1000046ca;

uint32_t _atoi(struct s0* rdi, struct s0* rsi) {
    goto _atoi;
}

int64_t _getuid = 0x100004788;

int32_t _getuid(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    goto _getuid;
}

int64_t _tgetent = 0x100004602;

int32_t _tgetent(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    goto _tgetent;
}

int64_t _tgetstr = 0x10000460c;

int64_t _tgetstr(int64_t rdi, int64_t rsi, struct s0* rdx) {
    goto _tgetstr;
}

int64_t _signal = 0x100004850;

void _signal(int64_t rdi, ...) {
    goto _signal;
}

struct s0* _strlen(struct s0* rdi, struct s0* rsi, ...);

struct s1 {
    signed char[4294987504] pad4294987504;
    unsigned char f4294987504;
};

int32_t ___tolower(int64_t rdi, struct s0* rsi, struct s0* rdx);

void _fprintf(int64_t rdi, struct s0* rsi, struct s0* rdx, ...);

void fun_100003a4d(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    void* rbp4;
    struct s0* rax5;
    struct s0* v6;
    struct s0* rax7;
    struct s1* v8;
    int32_t* r15_9;
    void* r14_10;
    int32_t r13d11;
    void* rcx12;
    struct s1* rdx13;
    struct s0* rbx14;
    unsigned char al15;
    struct s0* rdx16;
    int32_t* v17;
    int32_t* v18;
    void* r12_19;
    int32_t ebx20;
    int64_t rdi21;
    int32_t eax22;
    int64_t* rax23;
    int64_t rdi24;
    int16_t bx25;
    int64_t* rax26;
    int64_t rcx27;

    rbp4 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8);
    rax5 = reinterpret_cast<struct s0*>(0x100004ae8);
    if (rdi) {
        rax5 = rdi;
    }
    v6 = rax5;
    rax7 = _strlen(rax5, rsi);
    v8 = reinterpret_cast<struct s1*>(static_cast<int64_t>(*reinterpret_cast<int32_t*>(&rax7)));
    r15_9 = reinterpret_cast<int32_t*>(0x100005550);
    *reinterpret_cast<int32_t*>(&r14_10) = 0;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r14_10) + 4) = 0;
    r13d11 = 0;
    do {
        rcx12 = reinterpret_cast<void*>(reinterpret_cast<uint64_t>(r14_10) + reinterpret_cast<uint64_t>(r14_10) * 2);
        *reinterpret_cast<int32_t*>(0x100005550 + reinterpret_cast<uint64_t>(rcx12) * 4 + 8) = 0;
        rdx13 = reinterpret_cast<struct s1*>(reinterpret_cast<uint64_t>(r14_10) + reinterpret_cast<uint64_t>(r14_10));
        if (reinterpret_cast<int64_t>(v8) <= reinterpret_cast<int64_t>(rdx13)) {
            rbx14 = reinterpret_cast<struct s0*>(0x100004ef0);
            al15 = *reinterpret_cast<unsigned char*>(reinterpret_cast<uint64_t>(rdx13) + reinterpret_cast<unsigned char>(0x100004ef0));
        } else {
            rbx14 = v6;
            al15 = *reinterpret_cast<unsigned char*>(reinterpret_cast<unsigned char>(rbx14) + reinterpret_cast<uint64_t>(rdx13));
        }
        rdx16 = reinterpret_cast<struct s0*>((reinterpret_cast<uint64_t>(rdx13) | 1) + reinterpret_cast<unsigned char>(rbx14));
        v17 = reinterpret_cast<int32_t*>(0x100005550 + reinterpret_cast<uint64_t>(rcx12) * 4 + 8);
        v18 = r15_9;
        *reinterpret_cast<int32_t*>(&r12_19) = 0;
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r12_19) + 4) = 0;
        while (1) {
            ebx20 = static_cast<int32_t>(reinterpret_cast<signed char>(al15));
            if (static_cast<uint32_t>(reinterpret_cast<unsigned char>(*reinterpret_cast<unsigned char*>(&ebx20) & 0xf8)) != 48) {
                if (static_cast<uint32_t>(reinterpret_cast<unsigned char>(al15 + 0x9f)) > 7) {
                    if (static_cast<uint32_t>(reinterpret_cast<unsigned char>(al15 + 0xbf)) > 7) {
                        *reinterpret_cast<uint32_t*>(&rdi21) = static_cast<uint32_t>(static_cast<unsigned char>(reinterpret_cast<uint1_t>(static_cast<uint32_t>(al15) == 0x78)));
                        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi21) + 4) = 0;
                        eax22 = ___tolower(rdi21, rsi, rdx16);
                        if (!eax22) {
                            rax23 = ___stderrp;
                            rdi24 = *rax23;
                            rsi = reinterpret_cast<struct s0*>(0x100004d5a);
                            *reinterpret_cast<int32_t*>(&rdx16) = ebx20;
                            *reinterpret_cast<int32_t*>(&rdx16 + 4) = 0;
                            _fprintf(rdi24, 0x100004d5a, rdx16);
                        }
                        *r15_9 = -1;
                    } else {
                        *r15_9 = ebx20 - 65;
                        *v17 = 1;
                    }
                } else {
                    *r15_9 = ebx20 - 97;
                }
                bx25 = *reinterpret_cast<int16_t*>(&r13d11);
            } else {
                *r15_9 = ebx20 - 48;
                bx25 = 1;
                if (!*reinterpret_cast<int16_t*>(&r13d11)) {
                    rax26 = ___stderrp;
                    rcx27 = *rax26;
                    *reinterpret_cast<int32_t*>(&rsi) = 78;
                    *reinterpret_cast<int32_t*>(&rsi + 4) = 0;
                    *reinterpret_cast<int32_t*>(&rdx16) = 1;
                    *reinterpret_cast<int32_t*>(&rdx16 + 4) = 0;
                    _fwrite("warn: LSCOLORS should use characters a-h instead of 0-9 (see the manual page)\n", 78, 1, rcx27);
                }
            }
            if (reinterpret_cast<int1_t>(r12_19 == 1)) 
                break;
            al15 = *reinterpret_cast<unsigned char*>(reinterpret_cast<int64_t>(rbp4) + reinterpret_cast<int64_t>(r12_19) - 41);
            r12_19 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(r12_19) + 1);
            ++r15_9;
            *reinterpret_cast<int16_t*>(&r13d11) = bx25;
        }
        r14_10 = reinterpret_cast<void*>(reinterpret_cast<uint64_t>(r14_10) + 1);
        r15_9 = v18 + 3;
        *reinterpret_cast<int16_t*>(&r13d11) = bx25;
    } while (!reinterpret_cast<int1_t>(r14_10 == 11));
    return;
}

/* _fts_open$INODE64 */
int64_t _fts_open_INODE64 = 0x100004738;

/* _fts_open$INODE64 */
struct s0* _fts_open_INODE64(int64_t rdi, int64_t rsi, struct s0* rdx) {
    goto _fts_open_INODE64;
}

/* _fts_children$INODE64 */
int64_t _fts_children_INODE64 = 0x100004724;

/* _fts_children$INODE64 */
struct s0* _fts_children_INODE64(struct s0* rdi, ...) {
    goto _fts_children_INODE64;
}

int64_t* ___stack_chk_guard = reinterpret_cast<int64_t*>(0);

uint32_t g100005630 = 0;

uint32_t g10000562c = 0;

uint32_t g100005650 = 0;

struct s0* _malloc(struct s0* rdi, ...);

struct s2 {
    unsigned char f0;
    unsigned char f1;
    signed char f2;
    signed char f3;
};

uint32_t _sscanf();

int32_t g100005638 = 0;

int64_t ___stack_chk_fail(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...);

struct s0* _strerror(int64_t rdi, struct s0* rsi, struct s0* rdx, ...);

void _warnx(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...);

signed char g100005538 = 0;

unsigned char g100005504 = 0;

unsigned char g10000550c = 0;

uint32_t g100005644 = 0;

uint32_t g100005640 = 0;

struct s0* fun_100004020(struct s0* rdi, uint32_t esi, struct s0* rdx);

struct s3 {
    signed char[4] pad4;
    uint16_t f4;
    uint16_t f6;
    struct s0* f8;
    signed char[7] pad16;
    int32_t f16;
    int32_t f20;
    uint32_t f24;
    signed char[4] pad32;
    int64_t f32;
    signed char[8] pad48;
    int64_t f48;
    signed char[8] pad64;
    int64_t f64;
    signed char[8] pad80;
    int64_t f80;
    signed char[8] pad96;
    struct s0* f96;
    signed char[7] pad104;
    uint64_t f104;
    signed char[4] pad116;
    int32_t f116;
};

int32_t g10000563c = 0;

struct s0* _user_from_uid(int64_t rdi);

struct s0* _group_from_gid(int64_t rdi);

void ___snprintf_chk(struct s0* rdi, struct s0* rsi, ...);

int32_t g100005620 = 0;

struct s0* _calloc(int64_t rdi, uint64_t rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11);

void _strcpy();

struct s0* _listxattr(struct s0* rdi, ...);

int32_t g100005668 = 0;

struct s0* _reallocf(struct s0* rdi, int64_t rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11);

struct s0* _getxattr(struct s0* rdi, struct s0* rsi);

struct s0* _acl_get_link_np();

int32_t _acl_get_entry(struct s0* rdi, ...);

void _acl_free(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, ...);

int32_t g100005614 = 0;

void _free(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, ...);

struct s0* _fflagstostr(int64_t rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11);

struct s0* _strdup(int64_t rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11);

int64_t g100005530 = 0;

unsigned char g10000553c = 0;

void _err();

void fun_100001e8c(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    void* rsp4;
    void* rbp5;
    void* rsp6;
    struct s0* r15_7;
    struct s0* r13_8;
    struct s0* v9;
    int64_t* r14_10;
    int64_t r14_11;
    int64_t v12;
    uint32_t r12d13;
    uint32_t r12d14;
    uint32_t r14d15;
    struct s0* rax16;
    struct s0* v17;
    int32_t v18;
    int32_t v19;
    int32_t v20;
    uint64_t v21;
    struct s0* v22;
    struct s0* v23;
    uint64_t v24;
    uint32_t r12d25;
    uint32_t v26;
    struct s0* v27;
    struct s0* v28;
    int32_t v29;
    struct s0* rax30;
    struct s0* rax31;
    struct s0** rsp32;
    uint32_t ecx33;
    struct s2* rax34;
    unsigned char cl35;
    struct s2* rbx36;
    void* v37;
    void* v38;
    void* v39;
    void* v40;
    struct s0* v41;
    struct s0* r8_42;
    struct s0* r9_43;
    uint32_t eax44;
    int64_t rcx45;
    struct s0* rcx46;
    void* rax47;
    struct s0* rdx48;
    void* rax49;
    uint64_t rcx50;
    int64_t rax51;
    uint64_t rdx52;
    int64_t rax53;
    uint64_t rcx54;
    int64_t rax55;
    uint64_t rdx56;
    int64_t rax57;
    struct s0* rcx58;
    void* rax59;
    void* rax60;
    int64_t rax61;
    uint64_t rdi62;
    int64_t rax63;
    int32_t eax64;
    uint32_t eax65;
    uint32_t eax66;
    int64_t rdi67;
    struct s0* rax68;
    int1_t zf69;
    int1_t zf70;
    uint32_t eax71;
    uint32_t eax72;
    struct s0* rax73;
    struct s3* rbx74;
    uint64_t rax75;
    int1_t zf76;
    int1_t zf77;
    int64_t rdi78;
    struct s0* rax79;
    struct s0* r14_80;
    int64_t rdi81;
    struct s3* v82;
    struct s0* rsi83;
    struct s0* rax84;
    void* rsp85;
    struct s0* r12_86;
    struct s0* rbx87;
    struct s0* rax88;
    struct s0* r13_89;
    struct s0* rax90;
    struct s0* rax91;
    void* rsp92;
    struct s0* rbx93;
    struct s0* rax94;
    int1_t zf95;
    struct s0* rax96;
    void* rbx97;
    struct s0* rax98;
    struct s0* r14_99;
    struct s0* rdi100;
    struct s0* v101;
    struct s0** rsp102;
    void* v103;
    struct s0* rax104;
    struct s0* v105;
    struct s0* rbx106;
    struct s0* v107;
    struct s0* rcx108;
    struct s0* rax109;
    void* rsp110;
    struct s0* r15_111;
    int1_t zf112;
    struct s0* rax113;
    struct s0* r12_114;
    struct s0* r13_115;
    int32_t ebx116;
    struct s0* rax117;
    struct s0* eax118;
    struct s0* rax119;
    struct s0* rax120;
    int32_t eax121;
    int1_t zf122;
    int1_t zf123;
    int64_t rdi124;
    struct s0* rax125;
    struct s0* r15_126;
    int64_t* r14_127;
    struct s0* rbx128;
    int1_t zf129;
    struct s0* rbx130;
    struct s0* rdi131;
    struct s0* rdi132;
    struct s0* rdi133;

    rsp4 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8);
    rbp5 = rsp4;
    rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp4) - 8 - 8 - 8 - 8 - 8 - 0x578);
    r15_7 = rsi;
    r13_8 = rdi;
    v9 = r13_8;
    r14_10 = ___stack_chk_guard;
    r14_11 = *r14_10;
    v12 = r14_11;
    if (!r15_7) {
        addr_0x10000288c_2:
        if (r14_11 == v12) {
            return;
        }
    } else {
        r12d13 = g100005630;
        r12d14 = r12d13 | g10000562c;
        r14d15 = g100005650;
        rdi = reinterpret_cast<struct s0*>(0x100004ba2);
        rax16 = _getenv(0x100004ba2, rsi, rdx);
        rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8);
        v17 = reinterpret_cast<struct s0*>(0);
        v18 = 0;
        v19 = 0;
        v20 = 0;
        v21 = 0;
        v22 = reinterpret_cast<struct s0*>(0);
        v23 = reinterpret_cast<struct s0*>(0);
        v24 = 0;
        if (!rax16 || !*reinterpret_cast<struct s0**>(&rax16->f0)) {
            addr_0x100002190_5:
            r12d25 = r12d14 | r14d15;
            v26 = r12d25;
            v27 = r15_7;
            v28 = reinterpret_cast<struct s0*>(0);
            v29 = 0;
            goto addr_0x1000021ce_6;
        } else {
            rax30 = _strlen(rax16, rsi);
            rax31 = _malloc(reinterpret_cast<unsigned char>(rax30) + reinterpret_cast<unsigned char>(rax30) + 2);
            rsp32 = reinterpret_cast<struct s0**>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8);
            rdi = rax31;
            if (!rdi) {
                addr_0x1000028a4_8:
                rsi = reinterpret_cast<struct s0*>(0x100004baf);
                goto addr_0x1000028b4_9;
            } else {
                ecx33 = static_cast<uint32_t>(reinterpret_cast<unsigned char>(*reinterpret_cast<struct s0**>(&rax16->f0)));
                if (ecx33 != 58) {
                    rax34 = reinterpret_cast<struct s2*>(&rdi->f1);
                    *reinterpret_cast<struct s0**>(&rdi->f0) = *reinterpret_cast<struct s0**>(&ecx33);
                    rdi->f1 = 0;
                } else {
                    rdi->f2 = 0;
                    *reinterpret_cast<struct s0**>(&rdi->f0) = reinterpret_cast<struct s0*>(0x3a30);
                    rax34 = reinterpret_cast<struct s2*>(&rdi->f2);
                }
                cl35 = rax16->f1;
                if (cl35) {
                    rbx36 = reinterpret_cast<struct s2*>(&rax16->f2);
                    do {
                        if (static_cast<uint32_t>(cl35) != 58 || static_cast<uint32_t>(*reinterpret_cast<unsigned char*>(reinterpret_cast<uint64_t>(rbx36) - 2)) != 58) {
                            rax34->f0 = cl35;
                            rax34->f2 = 0;
                            rax34 = reinterpret_cast<struct s2*>(&rax34->f1);
                        } else {
                            rax34->f0 = 48;
                            rax34->f1 = *reinterpret_cast<unsigned char*>(reinterpret_cast<uint64_t>(rbx36) - 1);
                            rax34->f3 = 0;
                            rax34 = reinterpret_cast<struct s2*>(&rax34->f2);
                        }
                        cl35 = rbx36->f0;
                        rbx36 = reinterpret_cast<struct s2*>(&rbx36->f1);
                    } while (cl35);
                }
                if (static_cast<uint32_t>(*reinterpret_cast<unsigned char*>(reinterpret_cast<uint64_t>(rax34) - 1)) == 58) {
                    rax34->f0 = reinterpret_cast<unsigned char>(48);
                }
                v37 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp5) - 0x4d8);
                v38 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp5) - 0x4c8);
                v39 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp5) - 0x4b8);
                v40 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp5) - 0x4e4);
                v41 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xfffffffffffffb18);
                rsi = reinterpret_cast<struct s0*>(0x100004bb6);
                r8_42 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xfffffffffffffb30);
                r9_43 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xfffffffffffffb14);
                eax44 = _sscanf();
                rsp6 = reinterpret_cast<void*>(rsp32 - 8 + 8);
                g100005638 = 1;
                *reinterpret_cast<uint32_t*>(&rcx45) = eax44;
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx45) + 4) = 0;
                if (eax44 > 8) {
                    rcx46 = reinterpret_cast<struct s0*>(0);
                    *reinterpret_cast<int32_t*>(&rax47) = 1;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax47) + 4) = 0;
                    *reinterpret_cast<int32_t*>(&rdx48) = 0;
                    *reinterpret_cast<int32_t*>(&rdx48 + 4) = 0;
                    if (!1) {
                        do {
                            rax49 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rax47) + reinterpret_cast<int64_t>(rax47));
                            rax47 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rax49) + reinterpret_cast<int64_t>(rax49) * 4);
                            rcx46 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rcx46) - 1);
                        } while (rcx46);
                        rdx48 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rax47) - 1);
                    }
                    v23 = rdx48;
                    rcx50 = 0;
                    *reinterpret_cast<int32_t*>(&rax51) = 1;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax51) + 4) = 0;
                    *reinterpret_cast<int32_t*>(&rdx52) = 0;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdx52) + 4) = 0;
                    if (!1) {
                        do {
                            rax53 = rax51 + rax51;
                            rax51 = rax53 + rax53 * 4;
                            --rcx50;
                        } while (rcx50);
                        rdx52 = rax51 - 1;
                    }
                    v24 = rdx52;
                    rcx54 = 0;
                    *reinterpret_cast<int32_t*>(&rax55) = 1;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax55) + 4) = 0;
                    *reinterpret_cast<int32_t*>(&rdx56) = 0;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdx56) + 4) = 0;
                    if (!1) {
                        do {
                            rax57 = rax55 + rax55;
                            rax55 = rax57 + rax57 * 4;
                            --rcx54;
                        } while (rcx54);
                        rdx56 = reinterpret_cast<uint64_t>(rax55 - 1);
                    }
                    v21 = rdx56;
                    rcx58 = reinterpret_cast<struct s0*>(0);
                    *reinterpret_cast<int32_t*>(&rax59) = 1;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax59) + 4) = 0;
                    *reinterpret_cast<int32_t*>(&rdx) = 0;
                    *reinterpret_cast<int32_t*>(&rdx + 4) = 0;
                    if (!1) {
                        do {
                            rax60 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rax59) + reinterpret_cast<int64_t>(rax59));
                            rax59 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rax60) + reinterpret_cast<int64_t>(rax60) * 4);
                            rcx58 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rcx58) - 1);
                        } while (rcx58);
                        rdx = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rax59) - 1);
                    }
                    v17 = rdx;
                    goto addr_0x100002190_5;
                } else {
                    goto *reinterpret_cast<int32_t*>(0x1000028c8 + rcx45 * 4) + 0x1000028c8;
                }
            }
        }
    }
    addr_0x1000028c0_36:
    rax61 = ___stack_chk_fail(rdi, rsi, rdx, rdi, rsi, rdx);
    *reinterpret_cast<struct s0**>(&rdi->f0) = *reinterpret_cast<struct s0**>(&rsi->f0);
    rdi62 = reinterpret_cast<unsigned char>(rdi) + 4;
    *reinterpret_cast<int32_t*>(&rax63) = *reinterpret_cast<int32_t*>(&rax61) / *reinterpret_cast<int32_t*>(&rdi62) / *reinterpret_cast<int32_t*>(&rdi62) / *reinterpret_cast<int32_t*>(&rdi62);
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax63) + 4) = 0;
    eax64 = reinterpret_cast<int32_t>(rax63());
    eax64 % *reinterpret_cast<int32_t*>(&rdi62)();
    goto reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 - 8 + 8 - 8 + 8;
    do {
        addr_0x1000021ce_6:
        eax65 = static_cast<uint32_t>(*reinterpret_cast<uint16_t*>(reinterpret_cast<unsigned char>(r15_7) + 88));
        if (eax65 == 10 || (eax66 = static_cast<uint32_t>(*reinterpret_cast<uint16_t*>(&eax65)), eax66 == 7)) {
            *reinterpret_cast<struct s0**>(&rdi67) = *reinterpret_cast<struct s0**>(reinterpret_cast<unsigned char>(r15_7) + 56);
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi67) + 4) = 0;
            rax68 = _strerror(rdi67, rsi, rdx, rdi67, rsi, rdx);
            rcx58 = rax68;
            rdi = reinterpret_cast<struct s0*>(0x100004b87);
            rsi = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_7) + 0x68);
            rdx = rcx58;
            _warnx(0x100004b87, rsi, rdx, 0x100004b87, rsi, rdx);
            rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8);
            r15_7->f24 = reinterpret_cast<struct s0*>(1);
            g100005538 = 1;
            continue;
        } else {
            if (r13_8) {
                if (static_cast<uint32_t>(*reinterpret_cast<unsigned char*>(reinterpret_cast<unsigned char>(r15_7) + 0x68)) != 46) 
                    goto addr_0x100002249_43;
                zf69 = (g100005504 & 1) == 0;
                if (zf69) 
                    goto addr_0x10000223c_45;
                goto addr_0x100002249_43;
            }
            if (eax66 != 1 || (zf70 = (g10000550c & 1) == 0, !zf70)) {
                addr_0x100002249_43:
                *reinterpret_cast<uint32_t*>(&rsi) = static_cast<uint32_t>(*reinterpret_cast<uint16_t*>(reinterpret_cast<unsigned char>(r15_7) + 66));
                *reinterpret_cast<int32_t*>(&rsi + 4) = 0;
                if (reinterpret_cast<unsigned char>(rsi) > reinterpret_cast<unsigned char>(v22)) {
                    v22 = rsi;
                }
            } else {
                addr_0x10000223c_45:
                r15_7->f24 = reinterpret_cast<struct s0*>(1);
                continue;
            }
        }
        eax71 = g100005644;
        eax72 = eax71 | g100005640;
        if (eax72 && (rdi = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_7) + 0x68), rax73 = fun_100004020(rdi, *reinterpret_cast<uint32_t*>(&rsi), rdx), rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8), reinterpret_cast<unsigned char>(rax73) > reinterpret_cast<unsigned char>(v22))) {
            v22 = rax73;
        }
        if (!r12d25) {
            addr_0x1000026b5_52:
            ++v29;
            continue;
        } else {
            rbx74 = *reinterpret_cast<struct s3**>(reinterpret_cast<unsigned char>(r15_7) + 96);
            if (rbx74->f104 > v24) {
                v24 = rbx74->f104;
            }
            if (reinterpret_cast<unsigned char>(rbx74->f8) > reinterpret_cast<unsigned char>(v23)) {
                v23 = rbx74->f8;
            }
            *reinterpret_cast<uint32_t*>(&rax75) = static_cast<uint32_t>(rbx74->f6);
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax75) + 4) = 0;
            if (rax75 > v21) {
                v21 = rax75;
            }
            if (reinterpret_cast<signed char>(rbx74->f96) > reinterpret_cast<signed char>(v17)) {
                v17 = rbx74->f96;
            }
            zf76 = g100005630 == 0;
            if (!zf76) 
                goto addr_0x1000022f6_62;
        }
        goto addr_0x1000026b5_52;
        addr_0x1000022f6_62:
        zf77 = g10000563c == 0;
        *reinterpret_cast<int32_t*>(&r9_43) = rbx74->f16;
        *reinterpret_cast<int32_t*>(&r9_43 + 4) = 0;
        if (zf77) {
            *reinterpret_cast<int32_t*>(&rdi78) = *reinterpret_cast<int32_t*>(&r9_43);
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi78) + 4) = 0;
            rax79 = _user_from_uid(rdi78);
            r14_80 = rax79;
            *reinterpret_cast<int32_t*>(&rdi81) = rbx74->f20;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi81) + 4) = 0;
            v82 = rbx74;
            *reinterpret_cast<int32_t*>(&rsi83) = 0;
            *reinterpret_cast<int32_t*>(&rsi83 + 4) = 0;
            rax84 = _group_from_gid(rdi81);
            rsp85 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8);
            r12_86 = rax84;
        } else {
            v82 = rbx74;
            r14_80 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xffffffffffffff96);
            ___snprintf_chk(r14_80, 13, r14_80, 13);
            *reinterpret_cast<int32_t*>(&r9_43) = rbx74->f20;
            *reinterpret_cast<int32_t*>(&r9_43 + 4) = 0;
            *reinterpret_cast<int32_t*>(&rsi83) = 13;
            *reinterpret_cast<int32_t*>(&rsi83 + 4) = 0;
            *reinterpret_cast<int32_t*>(&rdx) = 0;
            *reinterpret_cast<int32_t*>(&rdx + 4) = 0;
            *reinterpret_cast<uint32_t*>(&rcx58) = 13;
            *reinterpret_cast<int32_t*>(&rcx58 + 4) = 0;
            rbx87 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xffffffffffffffa3);
            r8_42 = reinterpret_cast<struct s0*>(0x100004bea);
            ___snprintf_chk(rbx87, 13, rbx87, 13);
            rsp85 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8);
            r12_86 = rbx87;
        }
        rax88 = _strlen(r14_80, rsi83, r14_80, rsi83);
        r13_89 = rax88;
        *reinterpret_cast<int32_t*>(&rax90) = v20;
        *reinterpret_cast<int32_t*>(&rax90 + 4) = 0;
        if (reinterpret_cast<unsigned char>(r13_89) > reinterpret_cast<unsigned char>(rax90)) {
            v20 = *reinterpret_cast<int32_t*>(&r13_89);
        }
        rax91 = _strlen(r12_86, rsi83, r12_86, rsi83);
        rsp92 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp85) - 8 + 8 - 8 + 8);
        rbx93 = rax91;
        *reinterpret_cast<int32_t*>(&rax94) = v19;
        *reinterpret_cast<int32_t*>(&rax94 + 4) = 0;
        if (reinterpret_cast<unsigned char>(rbx93) > reinterpret_cast<unsigned char>(rax94)) {
            v19 = *reinterpret_cast<int32_t*>(&rbx93);
        }
        zf95 = g100005620 == 0;
        *reinterpret_cast<int32_t*>(&rax96) = 0;
        *reinterpret_cast<int32_t*>(&rax96 + 4) = 0;
        if (!zf95) 
            goto addr_0x1000023df_71;
        addr_0x10000243a_72:
        rbx97 = reinterpret_cast<void*>(reinterpret_cast<unsigned char>(rbx93) + reinterpret_cast<unsigned char>(r13_89));
        rax98 = _calloc(1, reinterpret_cast<unsigned char>(rax96) + reinterpret_cast<uint64_t>(rbx97) + 60, rdx, rcx58, r8_42, r9_43, v41, v40, v39, v38, v37);
        rsp32 = reinterpret_cast<struct s0**>(reinterpret_cast<int64_t>(rsp92) - 8 + 8);
        r14_99 = rax98;
        if (!r14_99) 
            goto addr_0x1000028a4_8;
        rdi100 = r14_99 + 1;
        v101 = rdi100;
        *reinterpret_cast<struct s0**>(&r14_99->f0) = rdi100;
        _strcpy();
        r14_99->f8 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r13_89) + reinterpret_cast<unsigned char>(r14_99) + 54);
        _strcpy();
        rsp102 = rsp32 - 8 + 8 - 8 + 8;
        if (!*reinterpret_cast<int16_t*>(reinterpret_cast<unsigned char>(r15_7) + 86)) {
            v103 = rbx97;
            rax104 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_7) + 0x68);
            v105 = r15_7;
        } else {
            v103 = rbx97;
            r9_43 = r15_7->f8->f40;
            v105 = r15_7;
            v41 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_7) + 0x68);
            rbx106 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xfffffffffffffb90);
            r8_42 = reinterpret_cast<struct s0*>(0x100004bfb);
            ___snprintf_chk(rbx106, 0x401, rbx106, 0x401);
            rsp102 = rsp102 - 8 + 8;
            rax104 = rbx106;
        }
        v107 = rax104;
        *reinterpret_cast<int32_t*>(&rdx) = 0;
        *reinterpret_cast<int32_t*>(&rdx + 4) = 0;
        *reinterpret_cast<int32_t*>(&rcx108) = 1;
        *reinterpret_cast<int32_t*>(&rcx108 + 4) = 0;
        rax109 = _listxattr(rax104);
        rsp110 = reinterpret_cast<void*>(rsp102 - 8 + 8);
        r15_111 = rax109;
        if (reinterpret_cast<signed char>(r15_111) < reinterpret_cast<signed char>(0)) {
            r15_111 = reinterpret_cast<struct s0*>(0);
        }
        zf112 = g100005668 == 0;
        if (!zf112 && !(reinterpret_cast<uint1_t>(reinterpret_cast<signed char>(r15_111) < reinterpret_cast<signed char>(0)) | reinterpret_cast<uint1_t>(r15_111 == 0))) {
            rax113 = _malloc(r15_111, r15_111);
            r14_99->f24 = rax113;
            *reinterpret_cast<int32_t*>(&rcx108) = 1;
            *reinterpret_cast<int32_t*>(&rcx108 + 4) = 0;
            rdx = r15_111;
            _listxattr(v107, v107);
            rsp110 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp110) - 8 + 8 - 8 + 8);
            r12_114 = r14_99->f24;
            r13_115 = r14_99->f32;
            ebx116 = r14_99->f48;
            do {
                rax117 = _reallocf(r13_115, ebx116 * 4 + 4, rdx, rcx108, r8_42, r9_43, v41, v40, v39, v38, v37);
                r14_99->f32 = rax117;
                *reinterpret_cast<int32_t*>(&rdx) = 0;
                *reinterpret_cast<int32_t*>(&rdx + 4) = 0;
                *reinterpret_cast<int32_t*>(&r8_42) = 0;
                *reinterpret_cast<int32_t*>(&r8_42 + 4) = 0;
                *reinterpret_cast<int32_t*>(&r9_43) = 1;
                *reinterpret_cast<int32_t*>(&r9_43 + 4) = 0;
                eax118 = _getxattr(v107, r12_114);
                rcx108 = reinterpret_cast<struct s0*>(static_cast<int64_t>(r14_99->f48));
                r13_115 = r14_99->f32;
                *reinterpret_cast<struct s0**>(reinterpret_cast<unsigned char>(r13_115) + reinterpret_cast<unsigned char>(rcx108) * 4) = eax118;
                ebx116 = r14_99->f48 + 1;
                r14_99->f48 = ebx116;
                rax119 = _strlen(r12_114, r12_114, r12_114, r12_114);
                rsp110 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp110) - 8 + 8 - 8 + 8 - 8 + 8);
                r12_114 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rax119) + reinterpret_cast<unsigned char>(r12_114) + 1);
            } while (reinterpret_cast<unsigned char>(r12_114) < reinterpret_cast<unsigned char>(reinterpret_cast<unsigned char>(r14_99->f24) + reinterpret_cast<unsigned char>(r15_111)));
        }
        *reinterpret_cast<uint32_t*>(&rsi) = 0x100;
        *reinterpret_cast<int32_t*>(&rsi + 4) = 0;
        rdi = v107;
        rax120 = _acl_get_link_np();
        rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp110) - 8 + 8);
        r14_99->f40 = rax120;
        if (rax120 && (*reinterpret_cast<uint32_t*>(&rsi) = 0, *reinterpret_cast<int32_t*>(&rsi + 4) = 0, rdi = rax120, rdx = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xfffffffffffffb08), eax121 = _acl_get_entry(rdi, rdi), rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8), eax121 == -1)) {
            rdi = r14_99->f40;
            _acl_free(rdi, 0, rdx, rcx108, r8_42, r9_43, v41, rdi, 0, rdx, rcx108, r8_42, r9_43, v41);
            rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8);
            r14_99->f40 = reinterpret_cast<struct s0*>(0);
        }
        r12d25 = v26;
        r13_8 = v9;
        if (reinterpret_cast<uint1_t>(reinterpret_cast<signed char>(r15_111) < reinterpret_cast<signed char>(0)) | reinterpret_cast<uint1_t>(r15_111 == 0)) {
            r15_7 = v105;
            if (!r14_99->f40) {
                r14_99->f52 = 32;
            } else {
                r14_99->f52 = 43;
            }
        } else {
            r14_99->f52 = 64;
            r15_7 = v105;
        }
        zf122 = g100005614 == 0;
        if (zf122) {
            rdi = r14_99->f40;
            _acl_free(rdi, rsi, rdx, rcx108, r8_42, r9_43, v41, rdi, rsi, rdx, rcx108, r8_42, r9_43, v41);
            rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8);
            r14_99->f40 = reinterpret_cast<struct s0*>(0);
        }
        *reinterpret_cast<uint32_t*>(&rcx58) = 0x4000;
        *reinterpret_cast<int32_t*>(&rcx58 + 4) = 0;
        if (((v82->f4 | 0x4000) & 0xf000) == 0x6000) {
        }
        zf123 = g100005620 == 0;
        if (!zf123) {
            rcx58 = v101;
            r14_99->f16 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rcx58) + reinterpret_cast<uint64_t>(v103) + 2);
            rsi = v28;
            _strcpy();
            rdi = v28;
            _free(rdi, rsi, rdx, rcx58, r8_42, r9_43, v41, rdi, rsi, rdx, rcx58, r8_42, r9_43, v41);
            rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8);
        }
        r15_7->f32 = r14_99;
        goto addr_0x1000026b5_52;
        addr_0x1000023df_71:
        *reinterpret_cast<int32_t*>(&rdi124) = v82->f116;
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi124) + 4) = 0;
        rax125 = _fflagstostr(rdi124, rsi83, rdx, rcx58, r8_42, r9_43, v41, v40, v39, v38, v37);
        rsp32 = reinterpret_cast<struct s0**>(reinterpret_cast<int64_t>(rsp92) - 8 + 8);
        if (!rax125) 
            goto addr_0x1000028ad_95;
        if (*reinterpret_cast<struct s0**>(&rax125->f0)) 
            goto addr_0x100002419_97;
        _free(rax125, rsi83, rdx, rcx58, r8_42, r9_43, v41, rax125, rsi83, rdx, rcx58, r8_42, r9_43, v41);
        rax125 = _strdup("-", rsi83, rdx, rcx58, r8_42, r9_43, v41, v40, v39, v38, v37);
        rsp32 = rsp32 - 8 + 8 - 8 + 8;
        if (!rax125) 
            goto addr_0x1000028ad_95;
        addr_0x100002419_97:
        v28 = rax125;
        rax96 = _strlen(rax125, rsi83, rax125, rsi83);
        rsp92 = reinterpret_cast<void*>(rsp32 - 8 + 8);
        rcx58 = reinterpret_cast<struct s0*>(static_cast<int64_t>(v18));
        if (reinterpret_cast<unsigned char>(rax96) <= reinterpret_cast<unsigned char>(rcx58)) 
            goto addr_0x10000243a_72;
        v18 = *reinterpret_cast<int32_t*>(&rax96);
        goto addr_0x10000243a_72;
        r15_7 = r15_7->f16;
    } while (r15_7);
    r15_126 = v27;
    r14_127 = ___stack_chk_guard;
    r14_11 = *r14_127;
    if (v29) {
        if (r12d25) {
            rbx128 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xffffffffffffffb0);
            ___snprintf_chk(rbx128, 24, rbx128, 24);
            _strlen(rbx128, 24, rbx128, 24);
            ___snprintf_chk(rbx128, 24, rbx128, 24);
            _strlen(rbx128, 24, rbx128, 24);
            ___snprintf_chk(rbx128, 24, rbx128, 24);
            _strlen(rbx128, 24, rbx128, 24);
            r9_43 = v17;
            *reinterpret_cast<uint32_t*>(&rsi) = 24;
            *reinterpret_cast<int32_t*>(&rsi + 4) = 0;
            *reinterpret_cast<int32_t*>(&rdx) = 0;
            *reinterpret_cast<int32_t*>(&rdx + 4) = 0;
            *reinterpret_cast<uint32_t*>(&rcx58) = 24;
            *reinterpret_cast<int32_t*>(&rcx58 + 4) = 0;
            r8_42 = reinterpret_cast<struct s0*>(0x100004c01);
            r14_11 = r14_11;
            ___snprintf_chk(rbx128, 24, rbx128, 24);
            _strlen(rbx128, 24, rbx128, 24);
            rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8 - 8 + 8 - 8 + 8 - 8 + 8 - 8 + 8 - 8 + 8 - 8 + 8);
        }
        rdi = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xfffffffffffffb50);
        g100005530();
        rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8);
        g10000553c = 1;
        zf129 = g100005630 == 0;
        if (!zf129) {
            do {
                rbx130 = r15_126->f32;
                if (rbx130) {
                    rdi131 = rbx130->f40;
                    if (rdi131) {
                        _acl_free(rdi131, rsi, rdx, rcx58, r8_42, r9_43, v41, rdi131, rsi, rdx, rcx58, r8_42, r9_43, v41);
                        rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8);
                    }
                    rdi132 = rbx130->f24;
                    _free(rdi132, rsi, rdx, rcx58, r8_42, r9_43, v41, rdi132, rsi, rdx, rcx58, r8_42, r9_43, v41);
                    rdi133 = rbx130->f32;
                    _free(rdi133, rsi, rdx, rcx58, r8_42, r9_43, v41, rdi133, rsi, rdx, rcx58, r8_42, r9_43, v41);
                    rdi = rbx130;
                    _free(rdi, rsi, rdx, rcx58, r8_42, r9_43, v41, rdi, rsi, rdx, rcx58, r8_42, r9_43, v41);
                    rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8 + 8 - 8 + 8);
                    r15_126->f32 = reinterpret_cast<struct s0*>(0);
                }
                r15_126 = r15_126->f16;
            } while (r15_126);
            goto addr_0x10000288c_2;
        }
    }
    addr_0x1000028ad_95:
    rsi = reinterpret_cast<struct s0*>(0x100004bef);
    addr_0x1000028b4_9:
    *reinterpret_cast<int32_t*>(&rdi) = 1;
    *reinterpret_cast<int32_t*>(&rdi + 4) = 0;
    _err();
    rsp6 = reinterpret_cast<void*>(rsp32 - 8 + 8);
    goto addr_0x1000028c0_36;
}

/* _fts_close$INODE64 */
int64_t _fts_close_INODE64 = 0x10000472e;

/* _fts_close$INODE64 */
void _fts_close_INODE64(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    goto _fts_close_INODE64;
}

struct s4 {
    signed char[56] pad56;
    int32_t f56;
    signed char[28] pad88;
    uint16_t f88;
    signed char[14] pad104;
    struct s0* f104;
};

/* _fts_read$INODE64 */
int64_t _fts_read_INODE64 = 0x100004742;

/* _fts_read$INODE64 */
struct s4* _fts_read_INODE64(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    goto _fts_read_INODE64;
}

int64_t _compat_mode = 0x1000046de;

unsigned char _compat_mode(int64_t rdi, struct s0* rsi, struct s0* rdx, ...) {
    goto _compat_mode;
}

struct s6 {
    signed char[4] pad4;
    uint16_t f4;
    signed char[2] pad8;
    struct s0* f8;
    signed char[95] pad104;
    int64_t f104;
};

struct s5 {
    uint32_t f0;
    signed char[12] pad16;
    struct s5* f16;
    int64_t f24;
    signed char[54] pad86;
    int16_t f86;
    signed char[8] pad96;
    struct s6* f96;
    struct s0* f104;
};

int64_t _printf = 0x10000480a;

struct s5* _printf(struct s0* rdi, ...) {
    goto _printf;
}

/* _fts_set$INODE64 */
int64_t _fts_set_INODE64 = 0x10000474c;

/* _fts_set$INODE64 */
void _fts_set_INODE64(int64_t rdi, int64_t rsi, int64_t rdx) {
    goto _fts_set_INODE64;
}

int64_t ___error = 0x10000463e;

int32_t* ___error(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...) {
    goto ___error;
}

int64_t _strlen = 0x100004896;

struct s0* _strlen(struct s0* rdi, struct s0* rsi, ...) {
    goto _strlen;
}

int64_t _malloc = 0x1000047d8;

struct s0* _malloc(struct s0* rdi, ...) {
    goto _malloc;
}

int64_t _strerror = 0x100004882;

struct s0* _strerror(int64_t rdi, struct s0* rsi, struct s0* rdx, ...) {
    goto _strerror;
}

int64_t _warnx = 0x1000048d2;

void _warnx(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...) {
    goto _warnx;
}

struct s0* _mbrtowc(struct s0* rdi, struct s0* rsi, struct s0* rdx, void* rcx);

uint32_t ___maskrune();

void* __DefaultRuneLocale = reinterpret_cast<void*>(0);

struct s5* _putchar();

struct s7 {
    signed char[1] pad1;
    signed char f1;
};

struct s7* _memchr(struct s0* rdi, struct s0* rsi, struct s0* rdx, void* rcx);

int32_t _wcwidth(struct s0* rdi, struct s0* rsi, struct s0* rdx, void* rcx);

struct s0* fun_100004020(struct s0* rdi, uint32_t esi, struct s0* rdx) {
    struct s0* rsi2;
    void* rsp4;
    void* rbp5;
    void* rsp6;
    struct s0* rbx7;
    int64_t* rax8;
    int64_t rax9;
    int64_t v10;
    struct s0* r14_11;
    struct s0* r15_12;
    void* r13_13;
    struct s0* rax14;
    int64_t* rax15;
    uint64_t rdi16;
    int32_t v17;
    uint32_t eax18;
    void* rax19;
    void* rcx20;
    void* rbp21;
    struct s0* rbx22;
    int64_t* rax23;
    int64_t v24;
    struct s0* rdi25;
    void* rcx26;
    struct s0* rdx27;
    struct s0* rsi28;
    struct s0* rax29;
    struct s0* r15_30;
    struct s0* r12_31;
    struct s0* rax32;
    uint64_t rdi33;
    int32_t v34;
    uint32_t eax35;
    void* rax36;
    uint32_t v37;
    struct s0* r14_38;
    struct s0* r13_39;
    struct s0* rax40;
    uint32_t ebx41;
    uint32_t eax42;
    struct s7* rax43;
    int32_t r14d44;
    struct s0* r12_45;
    uint32_t v46;
    int64_t* rax47;
    int64_t* rax48;
    int64_t rcx49;
    int64_t v50;
    int64_t* rax51;

    *reinterpret_cast<uint32_t*>(&rsi2) = esi;
    rsp4 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8);
    rbp5 = rsp4;
    rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp4) - 8 - 8 - 8 - 8 - 8 - 0x98);
    rbx7 = rdi;
    rax8 = ___stack_chk_guard;
    rax9 = *rax8;
    v10 = rax9;
    __asm__("xorps xmm0, xmm0");
    __asm__("movaps [rbp-0x40], xmm0");
    __asm__("movaps [rbp-0x50], xmm0");
    __asm__("movaps [rbp-0x60], xmm0");
    __asm__("movaps [rbp-0x70], xmm0");
    __asm__("movaps [rbp-0x80], xmm0");
    __asm__("movaps [rbp-0x90], xmm0");
    __asm__("movaps [rbp-0xa0], xmm0");
    __asm__("movaps [rbp-0xb0], xmm0");
    *reinterpret_cast<int32_t*>(&r14_11) = 0;
    *reinterpret_cast<int32_t*>(&r14_11 + 4) = 0;
    if (!*reinterpret_cast<uint32_t*>(&rsi2)) {
        addr_0x100004161_2:
        if (rax9 == v10) {
            return r14_11;
        }
    } else {
        r15_12 = reinterpret_cast<struct s0*>(static_cast<int64_t>(reinterpret_cast<int32_t>(*reinterpret_cast<uint32_t*>(&rsi2))));
        *reinterpret_cast<int32_t*>(&r14_11) = 0;
        *reinterpret_cast<int32_t*>(&r14_11 + 4) = 0;
        r13_13 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp5) - 0xb0);
        while (rdi = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp5) + 0xffffffffffffff4c), rsi2 = rbx7, rdx = r15_12, rax14 = _mbrtowc(rdi, rsi2, rdx, r13_13), rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8), rax14 != 0xfffffffffffffffe) {
            if (!rax14) 
                goto addr_0x100004157_7;
            if (rax14 == 0xffffffffffffffff) {
                r14_11 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r14_11) + 4);
                rbx7 = reinterpret_cast<struct s0*>(&rbx7->f1);
                r15_12 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_12) - 1);
                __asm__("xorps xmm0, xmm0");
                __asm__("movaps [rbp-0x40], xmm0");
                __asm__("movaps [rbp-0x50], xmm0");
                __asm__("movaps [rbp-0x60], xmm0");
                __asm__("movaps [rbp-0x70], xmm0");
                __asm__("movaps [rbp-0x80], xmm0");
                __asm__("movaps [rbp-0x90], xmm0");
                __asm__("movaps [rbp-0xa0], xmm0");
                __asm__("movaps [rbp-0xb0], xmm0");
                rax15 = ___stack_chk_guard;
                rax9 = *rax15;
                if (!*reinterpret_cast<int32_t*>(&r15_12)) 
                    goto addr_0x10000414b_10;
            } else {
                rdi16 = reinterpret_cast<uint64_t>(static_cast<int64_t>(v17));
                if (rdi16 > 0x7f) {
                    eax18 = ___maskrune();
                    rsp6 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8);
                } else {
                    rax19 = __DefaultRuneLocale;
                    eax18 = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rax19) + rdi16 * 4 + 60) & 0x40000;
                }
                rcx20 = reinterpret_cast<void*>(reinterpret_cast<unsigned char>(rax14) * 4);
                if (eax18) {
                    rcx20 = reinterpret_cast<void*>(1);
                }
                r14_11 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r14_11) + reinterpret_cast<uint64_t>(rcx20));
                rbx7 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rbx7) + reinterpret_cast<unsigned char>(rax14));
            }
        }
        goto addr_0x10000414d_17;
    }
    ___stack_chk_fail(rdi, rsi2, rdx, rdi, rsi2, rdx);
    rbp21 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp6) - 8 + 8 - 8);
    rbx22 = rdi;
    rax23 = ___stack_chk_guard;
    v24 = *rax23;
    __asm__("xorps xmm0, xmm0");
    __asm__("movaps [rbp-0x40], xmm0");
    __asm__("movaps [rbp-0x50], xmm0");
    __asm__("movaps [rbp-0x60], xmm0");
    __asm__("movaps [rbp-0x70], xmm0");
    __asm__("movaps [rbp-0x80], xmm0");
    __asm__("movaps [rbp-0x90], xmm0");
    __asm__("movaps [rbp-0xa0], xmm0");
    __asm__("movaps [rbp-0xb0], xmm0");
    rdi25 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp21) + 0xffffffffffffff4c);
    rcx26 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp21) - 0xb0);
    *reinterpret_cast<int32_t*>(&rdx27) = 6;
    *reinterpret_cast<int32_t*>(&rdx27 + 4) = 0;
    rsi28 = rbx22;
    rax29 = _mbrtowc(rdi25, rsi28, 6, rcx26);
    r15_30 = rax29;
    while (r15_30) {
        if (reinterpret_cast<unsigned char>(r15_30) > reinterpret_cast<unsigned char>(0xfffffffffffffffd)) {
            *reinterpret_cast<int32_t*>(&r12_31) = 1;
            if (r15_30 == 0xffffffffffffffff) 
                goto addr_0x1000042dc_23;
            rdi25 = rbx22;
            rax32 = _strlen(rdi25, rsi28, rdi25, rsi28);
            r12_31 = rax32;
        } else {
            rdi33 = reinterpret_cast<uint64_t>(static_cast<int64_t>(v34));
            if (rdi33 > 0x7f) {
                *reinterpret_cast<int32_t*>(&rsi28) = 0x40000;
                *reinterpret_cast<int32_t*>(&rsi28 + 4) = 0;
                eax35 = ___maskrune();
            } else {
                rax36 = __DefaultRuneLocale;
                *reinterpret_cast<uint32_t*>(&rcx26) = 0x40000;
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx26) + 4) = 0;
                eax35 = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rax36) + rdi33 * 4 + 60) & 0x40000;
            }
            *reinterpret_cast<uint32_t*>(&rdi25) = v37;
            *reinterpret_cast<int32_t*>(&rdi25 + 4) = 0;
            if (!eax35) 
                goto addr_0x100004282_29;
            if (*reinterpret_cast<uint32_t*>(&rdi25) == 34) 
                goto addr_0x100004282_29;
            if (*reinterpret_cast<uint32_t*>(&rdi25) != 92) 
                goto addr_0x100004390_32; else 
                goto addr_0x100004282_29;
        }
        if (reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r12_31) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r12_31) == 0)) {
            addr_0x100004348_34:
            if (r15_30 == 0xffffffffffffffff) {
                __asm__("xorps xmm0, xmm0");
                __asm__("movaps [rbp-0x40], xmm0");
                __asm__("movaps [rbp-0x50], xmm0");
                __asm__("movaps [rbp-0x60], xmm0");
                __asm__("movaps [rbp-0x70], xmm0");
                __asm__("movaps [rbp-0x80], xmm0");
                __asm__("movaps [rbp-0x90], xmm0");
                __asm__("movaps [rbp-0xa0], xmm0");
                __asm__("movaps [rbp-0xb0], xmm0");
                rbx22 = reinterpret_cast<struct s0*>(&rbx22->f1);
            } else {
                if (r15_30 == 0xfffffffffffffffe) 
                    break;
                rbx22 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rbx22) + reinterpret_cast<unsigned char>(r15_30));
            }
        } else {
            addr_0x1000042dc_23:
            r14_38 = rbx22;
            r13_39 = rbx22;
            goto addr_0x1000042f7_38;
        }
        *reinterpret_cast<int32_t*>(&rdx27) = 6;
        *reinterpret_cast<int32_t*>(&rdx27 + 4) = 0;
        rdi25 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp21) + 0xffffffffffffff4c);
        rsi28 = rbx22;
        rcx26 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp21) - 0xb0);
        rax40 = _mbrtowc(rdi25, rsi28, 6, rcx26);
        r15_30 = rax40;
        continue;
        do {
            addr_0x1000042f7_38:
            ebx41 = static_cast<uint32_t>(reinterpret_cast<unsigned char>(*reinterpret_cast<struct s0**>(&r14_38->f0)));
            _putchar();
            _putchar();
            _putchar();
            *reinterpret_cast<uint32_t*>(&rdi25) = ebx41 & 7 | 48;
            *reinterpret_cast<int32_t*>(&rdi25 + 4) = 0;
            _putchar();
            r14_38 = reinterpret_cast<struct s0*>(&r14_38->f1);
            *reinterpret_cast<int32_t*>(&r12_31) = *reinterpret_cast<int32_t*>(&r12_31) - 1;
        } while (*reinterpret_cast<int32_t*>(&r12_31));
        rbx22 = r13_39;
        goto addr_0x100004348_34;
        addr_0x100004282_29:
        r12_31 = r15_30;
        if (*reinterpret_cast<uint32_t*>(&rdi25) <= 0xff && ((eax42 = g100005644, r12_31 = r15_30, !!eax42) && (*reinterpret_cast<int32_t*>(&rsi28) = static_cast<int32_t>(*reinterpret_cast<signed char*>(&rdi25)), *reinterpret_cast<int32_t*>(&rsi28 + 4) = 0, *reinterpret_cast<int32_t*>(&rdx27) = 19, *reinterpret_cast<int32_t*>(&rdx27 + 4) = 0, rdi25 = reinterpret_cast<struct s0*>(0x100004a90), rax43 = _memchr(0x100004a90, rsi28, 19, rcx26), r12_31 = r15_30, !!rax43))) {
            _putchar();
            *reinterpret_cast<uint32_t*>(&rdi25) = reinterpret_cast<uint32_t>(static_cast<int32_t>(rax43->f1));
            *reinterpret_cast<int32_t*>(&rdi25 + 4) = 0;
            _putchar();
            goto addr_0x100004348_34;
        }
        addr_0x100004390_32:
        if (!(reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r15_30) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r15_30) == 0))) {
            r14d44 = *reinterpret_cast<int32_t*>(&r15_30);
            r12_45 = rbx22;
            do {
                _putchar();
                --r14d44;
            } while (r14d44);
            *reinterpret_cast<uint32_t*>(&rdi25) = v46;
            *reinterpret_cast<int32_t*>(&rdi25 + 4) = 0;
            rbx22 = r12_45;
        }
        _wcwidth(rdi25, rsi28, 6, rcx26);
        goto addr_0x100004348_34;
    }
    rax47 = ___stack_chk_guard;
    if (*rax47 == v24) 
        goto addr_0x1000043d7_47;
    ___stack_chk_fail(rdi25, rsi28, rdx27, rdi25, rsi28, rdx27);
    rax48 = ___stderrp;
    rcx49 = *rax48;
    _fwrite("usage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1] [file ...]\n", 62, 1, rcx49);
    _exit();
    addr_0x1000043d7_47:
    goto v50;
    addr_0x10000414d_17:
    *reinterpret_cast<int32_t*>(&r15_12) = *reinterpret_cast<int32_t*>(&r15_12) << 2;
    r14_11 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r14_11) + reinterpret_cast<uint64_t>(static_cast<int64_t>(*reinterpret_cast<int32_t*>(&r15_12))));
    addr_0x100004157_7:
    rax51 = ___stack_chk_guard;
    rax9 = *rax51;
    goto addr_0x100004161_2;
    addr_0x10000414b_10:
    goto addr_0x100004161_2;
}

int64_t ___snprintf_chk = 0x100004652;

void ___snprintf_chk(struct s0* rdi, struct s0* rsi, ...) {
    goto ___snprintf_chk;
}

int64_t _fflagstostr = 0x1000046fc;

struct s0* _fflagstostr(int64_t rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11) {
    goto _fflagstostr;
}

int64_t _free = 0x10000471a;

void _free(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, ...) {
    goto _free;
}

int64_t _strdup = 0x100004878;

struct s0* _strdup(int64_t rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11) {
    goto _strdup;
}

int64_t _strcpy = 0x10000486e;

void _strcpy() {
    goto _strcpy;
}

int64_t _listxattr = 0x1000047c4;

struct s0* _listxattr(struct s0* rdi, ...) {
    goto _listxattr;
}

int64_t _reallocf = 0x100004832;

struct s0* _reallocf(struct s0* rdi, int64_t rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11) {
    goto _reallocf;
}

int64_t _getxattr = 0x100004792;

struct s0* _getxattr(struct s0* rdi, struct s0* rsi) {
    goto _getxattr;
}

int64_t _acl_get_link_np = 0x100004698;

struct s0* _acl_get_link_np() {
    goto _acl_get_link_np;
}

int64_t _acl_get_entry = 0x10000467a;

int32_t _acl_get_entry(struct s0* rdi, ...) {
    goto _acl_get_entry;
}

int64_t _acl_free = 0x100004670;

void _acl_free(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, ...) {
    goto _acl_free;
}

uint64_t g100005600 = 0;

int32_t g10000561c = 0;

int32_t fun_1000034cf(uint32_t edi, struct s0* rsi, struct s0* rdx);

int32_t fun_100003595(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...);

int64_t g1000055e8 = 0;

void _tputs(int64_t rdi, struct s0* rsi, struct s0* rdx);

int64_t fun_100003c69();

int64_t g1000055f8 = 0;

uint32_t g100005664 = 0;

int32_t fun_1000035cb(uint32_t edi, struct s0* rsi, struct s0* rdx);

struct s5* fun_1000029ba(struct s5* rdi, struct s0* rsi, struct s0* rdx) {
    struct s0* r15_4;
    struct s6* r12_5;
    int32_t r14d6;
    int1_t zf7;
    struct s5* rax8;
    int1_t zf9;
    uint64_t rdx10;
    void* rax11;
    struct s5* rax12;
    int1_t zf13;
    int32_t r13d14;
    uint32_t edi15;
    int32_t eax16;
    int32_t eax17;
    int32_t eax18;
    int64_t rdi19;
    int64_t rdi20;
    int32_t ebx21;
    int1_t zf22;
    uint32_t edi23;
    int32_t eax24;
    struct s5* rax25;

    r15_4 = rdx;
    r12_5 = rdi->f96;
    r14d6 = 0;
    zf7 = g10000562c == 0;
    if (!zf7) {
        rdx = r12_5->f8;
        rax8 = _printf(0x100004c7e, 0x100004c7e);
        r14d6 = *reinterpret_cast<int32_t*>(&rax8);
    }
    zf9 = g100005650 == 0;
    if (!zf9) {
        rdx10 = reinterpret_cast<uint64_t>(r12_5->f104 % reinterpret_cast<int64_t>(g100005600));
        rax11 = reinterpret_cast<void*>(r12_5->f104 / reinterpret_cast<int64_t>(g100005600));
        *reinterpret_cast<int32_t*>(&rsi) = *reinterpret_cast<int32_t*>(&r15_4);
        *reinterpret_cast<int32_t*>(&rsi + 4) = 0;
        rdx = reinterpret_cast<struct s0*>(reinterpret_cast<uint64_t>(rax11) - (1 - static_cast<uint64_t>(reinterpret_cast<uint1_t>(reinterpret_cast<uint64_t>(rax11) < 1 - static_cast<uint64_t>(reinterpret_cast<uint1_t>(rdx10 < 1))))));
        rax12 = _printf(0x100004c85, 0x100004c85);
        r14d6 = r14d6 + *reinterpret_cast<int32_t*>(&rax12);
    }
    zf13 = g10000561c == 0;
    if (zf13) {
        r13d14 = 0;
    } else {
        edi15 = static_cast<uint32_t>(r12_5->f4);
        eax16 = fun_1000034cf(edi15, rsi, rdx);
        *reinterpret_cast<unsigned char*>(&r13d14) = static_cast<unsigned char>(reinterpret_cast<uint1_t>(!!eax16));
    }
    eax17 = fun_100003595(&rdi->f104, rsi, rdx);
    if (*reinterpret_cast<unsigned char*>(&r13d14) && (eax18 = g10000561c, !!eax18)) {
        rdi19 = g1000055e8;
        _tputs(rdi19, 1, fun_100003c69);
        rdi20 = g1000055f8;
        *reinterpret_cast<int32_t*>(&rsi) = 1;
        *reinterpret_cast<int32_t*>(&rsi + 4) = 0;
        rdx = reinterpret_cast<struct s0*>(fun_100003c69);
        _tputs(rdi20, 1, fun_100003c69);
    }
    ebx21 = eax17 + r14d6;
    zf22 = g100005664 == 0;
    if (!zf22) {
        edi23 = static_cast<uint32_t>(r12_5->f4);
        eax24 = fun_1000035cb(edi23, rsi, rdx);
        ebx21 = ebx21 + eax24;
    }
    *reinterpret_cast<int32_t*>(&rax25) = ebx21;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax25) + 4) = 0;
    return rax25;
}

int64_t _putchar = 0x100004814;

struct s5* _putchar() {
    goto _putchar;
}

void fun_100003c76(int32_t edi, struct s0* rsi, struct s0* rdx);

int32_t fun_1000034cf(uint32_t edi, struct s0* rsi, struct s0* rdx) {
    uint32_t eax4;
    uint32_t ecx5;
    int32_t edi6;
    int32_t ebx7;

    eax4 = edi;
    ecx5 = eax4 & 0xf000;
    if (reinterpret_cast<int32_t>(ecx5) > reinterpret_cast<int32_t>(0x5fff)) {
        if (ecx5 == 0x6000) {
            edi6 = 5;
        } else {
            if (ecx5 == 0xa000) {
                ebx7 = 1;
                fun_100003c76(1, rsi, rdx);
                goto addr_0x10000358c_6;
            }
            if (ecx5 != 0xc000) 
                goto addr_0x10000354c_8; else 
                goto addr_0x10000351f_9;
        }
    } else {
        if (ecx5 == 0x1000) {
            edi6 = 3;
        } else {
            if (ecx5 == 0x2000) {
                edi6 = 6;
            } else {
                if (ecx5 != 0x4000) {
                    addr_0x10000354c_8:
                    ebx7 = 0;
                    if (!(*reinterpret_cast<unsigned char*>(&eax4) & 73)) {
                        addr_0x10000358c_6:
                        return ebx7;
                    } else {
                        if (*reinterpret_cast<unsigned char*>(reinterpret_cast<int64_t>(&eax4) + 1) & 8) {
                            edi6 = 7;
                        } else {
                            if (*reinterpret_cast<unsigned char*>(reinterpret_cast<int64_t>(&eax4) + 1) & 4) {
                                edi6 = 8;
                            } else {
                                edi6 = 4;
                            }
                        }
                    }
                } else {
                    if (*reinterpret_cast<unsigned char*>(&eax4) & 2) {
                        if (*reinterpret_cast<unsigned char*>(reinterpret_cast<int64_t>(&eax4) + 1) & 2) {
                            edi6 = 9;
                        } else {
                            edi6 = 10;
                        }
                    } else {
                        edi6 = 0;
                    }
                }
            }
        }
    }
    addr_0x100003582_25:
    fun_100003c76(edi6, rsi, rdx);
    ebx7 = 1;
    goto addr_0x10000358c_6;
    addr_0x10000351f_9:
    edi6 = 2;
    goto addr_0x100003582_25;
}

int64_t _tputs = 0x100004620;

void _tputs(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    goto _tputs;
}

uint32_t g100005654 = 0;

int32_t fun_1000035cb(uint32_t edi, struct s0* rsi, struct s0* rdx) {
    uint32_t ecx4;
    int1_t zf5;
    int32_t eax6;

    ecx4 = edi & 0xf000;
    zf5 = g100005654 == 0;
    if (zf5) {
        if (reinterpret_cast<int32_t>(ecx4) <= reinterpret_cast<int32_t>(0x9fff)) {
            if (ecx4 != 0x1000) {
                if (ecx4 != 0x4000) {
                    addr_0x10000364c_6:
                    eax6 = 0;
                    if (!(*reinterpret_cast<unsigned char*>(&edi) & 73)) {
                        addr_0x100003635_7:
                        return eax6;
                    }
                } else {
                    addr_0x100003626_9:
                }
            }
        } else {
            if (ecx4 != 0xa000) {
                if (ecx4 != 0xc000) {
                    if (ecx4 != 0xe000) 
                        goto addr_0x10000364c_6;
                }
            }
        }
        _putchar();
        eax6 = 1;
        goto addr_0x100003635_7;
    } else {
        eax6 = 0;
        if (ecx4 != 0x4000) 
            goto addr_0x100003635_7;
        goto addr_0x100003626_9;
    }
}

int64_t _strmode = 0x1000048a0;

void _strmode(int64_t rdi, void* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, struct s0* a8, struct s0* a9) {
    goto _strmode;
}

uint32_t g100005634 = 0;

int32_t fun_100003595(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...) {
    void* rsp4;
    uint32_t ecx5;
    uint32_t ecx6;
    int1_t zf7;
    void* rsp8;
    void* rbp9;
    void* rsp10;
    struct s0* r15_11;
    int64_t* rax12;
    int64_t v13;
    int32_t v14;
    void* r12_15;
    struct s0* rsi16;
    void* rcx17;
    struct s0* rax18;
    struct s0* rbx19;
    uint64_t rdi20;
    int32_t v21;
    uint32_t eax22;
    void* rax23;
    struct s0* rdi24;
    int32_t v25;
    int32_t eax26;
    int64_t r14_27;
    void* rsp28;
    void* rsp29;
    struct s5* rax30;
    int32_t ecx31;
    int64_t* rax32;
    void* rsp33;
    void* rbp34;
    void* rsp35;
    struct s0* r12_36;
    int64_t* rax37;
    int64_t r14_38;
    struct s0* r15_39;
    void* r13_40;
    struct s0* rdx41;
    struct s0* rsi42;
    void* rcx43;
    struct s0* rax44;
    void* rsp45;
    struct s0* rbx46;
    uint64_t rdi47;
    int32_t v48;
    uint32_t eax49;
    void* rax50;
    int32_t r15d51;
    struct s0* rdi52;
    int32_t v53;
    int32_t eax54;
    int64_t* rax55;
    void* rsp56;
    void* rbp57;
    void* rsp58;
    struct s0* rbx59;
    int64_t* rax60;
    int64_t rax61;
    int64_t v62;
    int64_t v63;
    void* rbp64;
    struct s0* rbx65;
    int64_t* rax66;
    struct s0* rdi67;
    void* rcx68;
    struct s0* rdx69;
    struct s0* rsi70;
    struct s0* rax71;
    struct s0* r15_72;
    int32_t r14d73;
    struct s0* r12_74;
    struct s0* rax75;
    uint64_t rdi76;
    int32_t v77;
    uint32_t eax78;
    void* rax79;
    uint32_t v80;
    int32_t v81;
    struct s0* r14_82;
    struct s0* r13_83;
    struct s0* rax84;
    uint32_t ebx85;
    uint32_t eax86;
    struct s7* rax87;
    int32_t r13d88;
    int32_t r14d89;
    struct s0* r12_90;
    uint32_t v91;
    int32_t eax92;
    int64_t* rax93;
    int64_t* rax94;
    int64_t rcx95;
    struct s0* rax96;
    int64_t* rax97;
    uint64_t rdi98;
    int32_t v99;
    uint32_t eax100;
    void* rax101;
    int64_t* rax102;

    rsp4 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8);
    ecx5 = g100005644;
    ecx6 = ecx5 | g100005640;
    if (!ecx6) {
        zf7 = g100005634 == 0;
        if (zf7) {
            rsp8 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp4) + 8 - 8);
            rbp9 = rsp8;
            rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp8) - 8 - 8 - 8 - 8 - 8 - 0x98);
            r15_11 = rdi;
            rax12 = ___stack_chk_guard;
            v13 = *rax12;
            __asm__("xorps xmm0, xmm0");
            __asm__("movaps [rbp-0x40], xmm0");
            __asm__("movaps [rbp-0x50], xmm0");
            __asm__("movaps [rbp-0x60], xmm0");
            __asm__("movaps [rbp-0x70], xmm0");
            __asm__("movaps [rbp-0x80], xmm0");
            __asm__("movaps [rbp-0x90], xmm0");
            __asm__("movaps [rbp-0xa0], xmm0");
            __asm__("movaps [rbp-0xb0], xmm0");
            v14 = 0;
            r12_15 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp9) - 0xb0);
            while (rdi = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp9) + 0xffffffffffffff4c), rsi16 = r15_11, rcx17 = r12_15, rax18 = _mbrtowc(rdi, rsi16, 6, rcx17), rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8), rbx19 = rax18, rbx19 != 0xfffffffffffffffe) {
                if (rbx19 == 0xffffffffffffffff) {
                    __asm__("xorps xmm0, xmm0");
                    __asm__("movaps [rbp-0x40], xmm0");
                    __asm__("movaps [rbp-0x50], xmm0");
                    __asm__("movaps [rbp-0x60], xmm0");
                    __asm__("movaps [rbp-0x70], xmm0");
                    __asm__("movaps [rbp-0x80], xmm0");
                    __asm__("movaps [rbp-0x90], xmm0");
                    __asm__("movaps [rbp-0xa0], xmm0");
                    __asm__("movaps [rbp-0xb0], xmm0");
                    _putchar();
                    rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8);
                    r15_11 = reinterpret_cast<struct s0*>(&r15_11->f1);
                    ++v14;
                    continue;
                }
                if (!rbx19) 
                    goto addr_0x100003e7a_9;
                if (!(reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&rbx19) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&rbx19) == 0))) 
                    goto addr_0x100003dc9_11;
                addr_0x100003de1_12:
                rdi20 = reinterpret_cast<uint64_t>(static_cast<int64_t>(v21));
                if (rdi20 > 0x7f) {
                    *reinterpret_cast<int32_t*>(&rsi16) = 0x40000;
                    *reinterpret_cast<int32_t*>(&rsi16 + 4) = 0;
                    eax22 = ___maskrune();
                    rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8);
                } else {
                    rax23 = __DefaultRuneLocale;
                    *reinterpret_cast<uint32_t*>(&rcx17) = 0x40000;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx17) + 4) = 0;
                    eax22 = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rax23) + rdi20 * 4 + 60) & 0x40000;
                }
                r15_11 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_11) + reinterpret_cast<unsigned char>(rbx19));
                if (!eax22) 
                    continue;
                *reinterpret_cast<int32_t*>(&rdi24) = v25;
                *reinterpret_cast<int32_t*>(&rdi24 + 4) = 0;
                eax26 = _wcwidth(rdi24, rsi16, 6, rcx17);
                rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8);
                v14 = v14 + eax26;
                continue;
                addr_0x100003dc9_11:
                *reinterpret_cast<int32_t*>(&r14_27) = *reinterpret_cast<int32_t*>(&rbx19);
                do {
                    _putchar();
                    rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8);
                    *reinterpret_cast<int32_t*>(&r14_27) = *reinterpret_cast<int32_t*>(&r14_27) - 1;
                } while (*reinterpret_cast<int32_t*>(&r14_27));
                goto addr_0x100003de1_12;
            }
        } else {
            rsp28 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp4) + 8);
            goto addr_0x100003ea9_20;
        }
    } else {
        rsp29 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp4) + 8);
        goto addr_0x100004181_22;
    }
    rdi = reinterpret_cast<struct s0*>(0x100004f07);
    rsi16 = r15_11;
    rax30 = _printf(0x100004f07, 0x100004f07);
    rsp10 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8);
    ecx31 = v14 + *reinterpret_cast<int32_t*>(&rax30);
    addr_0x100003e80_24:
    rax32 = ___stack_chk_guard;
    if (*rax32 != v13) {
        ___stack_chk_fail(rdi, rsi16, 6);
        rsp28 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp10) - 8 + 8);
    } else {
        return ecx31;
    }
    addr_0x100003ea9_20:
    rsp33 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp28) - 8);
    rbp34 = rsp33;
    rsp35 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp33) - 8 - 8 - 8 - 8 - 8 - 0x98);
    r12_36 = rdi;
    rax37 = ___stack_chk_guard;
    v13 = *rax37;
    __asm__("xorps xmm0, xmm0");
    __asm__("movaps [rbp-0x40], xmm0");
    __asm__("movaps [rbp-0x50], xmm0");
    __asm__("movaps [rbp-0x60], xmm0");
    __asm__("movaps [rbp-0x70], xmm0");
    __asm__("movaps [rbp-0x80], xmm0");
    __asm__("movaps [rbp-0x90], xmm0");
    __asm__("movaps [rbp-0xa0], xmm0");
    __asm__("movaps [rbp-0xb0], xmm0");
    *reinterpret_cast<int32_t*>(&r14_38) = 0;
    while (1) {
        r15_39 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp34) + 0xffffffffffffff4c);
        r13_40 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp34) - 0xb0);
        while (1) {
            *reinterpret_cast<int32_t*>(&rdx41) = 6;
            *reinterpret_cast<int32_t*>(&rdx41 + 4) = 0;
            rdi = r15_39;
            rsi42 = r12_36;
            rcx43 = r13_40;
            rax44 = _mbrtowc(rdi, rsi42, 6, rcx43);
            rsp45 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp35) - 8 + 8);
            rbx46 = rax44;
            if (rbx46 == 0xffffffffffffffff) {
                _putchar();
                rsp35 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8);
                r12_36 = reinterpret_cast<struct s0*>(&r12_36->f1);
                *reinterpret_cast<int32_t*>(&r14_38) = *reinterpret_cast<int32_t*>(&r14_38) + 1;
                __asm__("xorps xmm0, xmm0");
                __asm__("movaps [rbp-0x40], xmm0");
                __asm__("movaps [rbp-0x50], xmm0");
                __asm__("movaps [rbp-0x60], xmm0");
                __asm__("movaps [rbp-0x70], xmm0");
                __asm__("movaps [rbp-0x80], xmm0");
                __asm__("movaps [rbp-0x90], xmm0");
                __asm__("movaps [rbp-0xa0], xmm0");
                __asm__("movaps [rbp-0xb0], xmm0");
                continue;
            }
            if (rbx46 == 0xfffffffffffffffe) 
                goto addr_0x100003fe9_31;
            if (!rbx46) 
                goto addr_0x100003ff6_33;
            rdi47 = reinterpret_cast<uint64_t>(static_cast<int64_t>(v48));
            if (rdi47 <= 0x7f) 
                goto addr_0x100003f90_35;
            *reinterpret_cast<int32_t*>(&rsi42) = 0x40000;
            *reinterpret_cast<int32_t*>(&rsi42 + 4) = 0;
            eax49 = ___maskrune();
            rsp45 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8);
            addr_0x100003fae_37:
            if (eax49) 
                break;
            _putchar();
            rsp35 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8);
            r12_36 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r12_36) + reinterpret_cast<unsigned char>(rbx46));
            *reinterpret_cast<int32_t*>(&r14_38) = *reinterpret_cast<int32_t*>(&r14_38) + 1;
            continue;
            addr_0x100003f90_35:
            rax50 = __DefaultRuneLocale;
            *reinterpret_cast<uint32_t*>(&rcx43) = 0x40000;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx43) + 4) = 0;
            eax49 = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rax50) + rdi47 * 4 + 60) & 0x40000;
            goto addr_0x100003fae_37;
        }
        if (!(reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&rbx46) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&rbx46) == 0))) {
            r15d51 = *reinterpret_cast<int32_t*>(&rbx46);
            do {
                _putchar();
                rsp45 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8);
                --r15d51;
            } while (r15d51);
        }
        r12_36 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r12_36) + reinterpret_cast<unsigned char>(rbx46));
        *reinterpret_cast<int32_t*>(&rdi52) = v53;
        *reinterpret_cast<int32_t*>(&rdi52 + 4) = 0;
        eax54 = _wcwidth(rdi52, rsi42, 6, rcx43);
        rsp35 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8);
        *reinterpret_cast<int32_t*>(&r14_38) = *reinterpret_cast<int32_t*>(&r14_38) + eax54;
    }
    addr_0x100003fe9_31:
    *reinterpret_cast<int32_t*>(&rdi) = 63;
    *reinterpret_cast<int32_t*>(&rdi + 4) = 0;
    _putchar();
    rsp45 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8);
    *reinterpret_cast<int32_t*>(&r14_38) = *reinterpret_cast<int32_t*>(&r14_38) + 1;
    addr_0x100003ff6_33:
    rax55 = ___stack_chk_guard;
    if (*rax55 == v13) {
        return *reinterpret_cast<int32_t*>(&r14_38);
    }
    ___stack_chk_fail(rdi, rsi42, 6, rdi, rsi42, 6);
    rsp56 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp45) - 8 + 8 - 8);
    rbp57 = rsp56;
    rsp58 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp56) - 8 - 8 - 8 - 8 - 8 - 0x98);
    rbx59 = rdi;
    rax60 = ___stack_chk_guard;
    rax61 = *rax60;
    v62 = rax61;
    __asm__("xorps xmm0, xmm0");
    __asm__("movaps [rbp-0x40], xmm0");
    __asm__("movaps [rbp-0x50], xmm0");
    __asm__("movaps [rbp-0x60], xmm0");
    __asm__("movaps [rbp-0x70], xmm0");
    __asm__("movaps [rbp-0x80], xmm0");
    __asm__("movaps [rbp-0x90], xmm0");
    __asm__("movaps [rbp-0xa0], xmm0");
    __asm__("movaps [rbp-0xb0], xmm0");
    if (*reinterpret_cast<int32_t*>(&rsi42)) 
        goto addr_0x10000407c_47;
    addr_0x100004161_48:
    if (rax61 != v62) {
        ___stack_chk_fail(rdi, rsi42, rdx41, rdi, rsi42, rdx41);
        rsp29 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp58) - 8 + 8);
    } else {
        goto v63;
    }
    addr_0x100004181_22:
    rbp64 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp29) - 8);
    rbx65 = rdi;
    rax66 = ___stack_chk_guard;
    v13 = *rax66;
    __asm__("xorps xmm0, xmm0");
    __asm__("movaps [rbp-0x40], xmm0");
    __asm__("movaps [rbp-0x50], xmm0");
    __asm__("movaps [rbp-0x60], xmm0");
    __asm__("movaps [rbp-0x70], xmm0");
    __asm__("movaps [rbp-0x80], xmm0");
    __asm__("movaps [rbp-0x90], xmm0");
    __asm__("movaps [rbp-0xa0], xmm0");
    __asm__("movaps [rbp-0xb0], xmm0");
    rdi67 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp64) + 0xffffffffffffff4c);
    rcx68 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp64) - 0xb0);
    *reinterpret_cast<int32_t*>(&rdx69) = 6;
    *reinterpret_cast<int32_t*>(&rdx69 + 4) = 0;
    rsi70 = rbx65;
    rax71 = _mbrtowc(rdi67, rsi70, 6, rcx68);
    r15_72 = rax71;
    r14d73 = 0;
    while (r15_72) {
        if (reinterpret_cast<unsigned char>(r15_72) > reinterpret_cast<unsigned char>(0xfffffffffffffffd)) {
            *reinterpret_cast<int32_t*>(&r12_74) = 1;
            *reinterpret_cast<int32_t*>(&r12_74 + 4) = 0;
            if (r15_72 == 0xffffffffffffffff) 
                goto addr_0x1000042dc_54;
            rdi67 = rbx65;
            rax75 = _strlen(rdi67, rsi70, rdi67, rsi70);
            r12_74 = rax75;
        } else {
            rdi76 = reinterpret_cast<uint64_t>(static_cast<int64_t>(v77));
            if (rdi76 > 0x7f) {
                *reinterpret_cast<int32_t*>(&rsi70) = 0x40000;
                *reinterpret_cast<int32_t*>(&rsi70 + 4) = 0;
                eax78 = ___maskrune();
            } else {
                rax79 = __DefaultRuneLocale;
                *reinterpret_cast<uint32_t*>(&rcx68) = 0x40000;
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx68) + 4) = 0;
                eax78 = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rax79) + rdi76 * 4 + 60) & 0x40000;
            }
            *reinterpret_cast<uint32_t*>(&rdi67) = v80;
            *reinterpret_cast<int32_t*>(&rdi67 + 4) = 0;
            if (!eax78) 
                goto addr_0x100004282_60;
            if (*reinterpret_cast<uint32_t*>(&rdi67) == 34) 
                goto addr_0x100004282_60;
            if (*reinterpret_cast<uint32_t*>(&rdi67) != 92) 
                goto addr_0x100004390_63; else 
                goto addr_0x100004282_60;
        }
        if (reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r12_74) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r12_74) == 0)) {
            addr_0x100004348_65:
            if (r15_72 == 0xffffffffffffffff) {
                __asm__("xorps xmm0, xmm0");
                __asm__("movaps [rbp-0x40], xmm0");
                __asm__("movaps [rbp-0x50], xmm0");
                __asm__("movaps [rbp-0x60], xmm0");
                __asm__("movaps [rbp-0x70], xmm0");
                __asm__("movaps [rbp-0x80], xmm0");
                __asm__("movaps [rbp-0x90], xmm0");
                __asm__("movaps [rbp-0xa0], xmm0");
                __asm__("movaps [rbp-0xb0], xmm0");
                rbx65 = reinterpret_cast<struct s0*>(&rbx65->f1);
            } else {
                if (r15_72 == 0xfffffffffffffffe) 
                    break;
                rbx65 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rbx65) + reinterpret_cast<unsigned char>(r15_72));
            }
        } else {
            addr_0x1000042dc_54:
            v14 = r14d73;
            v81 = static_cast<int32_t>(reinterpret_cast<unsigned char>(r12_74) * 4);
            r14_82 = rbx65;
            r13_83 = rbx65;
            goto addr_0x1000042f7_69;
        }
        *reinterpret_cast<int32_t*>(&rdx69) = 6;
        *reinterpret_cast<int32_t*>(&rdx69 + 4) = 0;
        rdi67 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp64) + 0xffffffffffffff4c);
        rsi70 = rbx65;
        rcx68 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp64) - 0xb0);
        rax84 = _mbrtowc(rdi67, rsi70, 6, rcx68);
        r15_72 = rax84;
        continue;
        do {
            addr_0x1000042f7_69:
            ebx85 = static_cast<uint32_t>(reinterpret_cast<unsigned char>(*reinterpret_cast<struct s0**>(&r14_82->f0)));
            _putchar();
            _putchar();
            _putchar();
            *reinterpret_cast<uint32_t*>(&rdi67) = ebx85 & 7 | 48;
            *reinterpret_cast<int32_t*>(&rdi67 + 4) = 0;
            _putchar();
            r14_82 = reinterpret_cast<struct s0*>(&r14_82->f1);
            *reinterpret_cast<int32_t*>(&r12_74) = *reinterpret_cast<int32_t*>(&r12_74) - 1;
        } while (*reinterpret_cast<int32_t*>(&r12_74));
        r14d73 = v14 + v81;
        rbx65 = r13_83;
        goto addr_0x100004348_65;
        addr_0x100004282_60:
        r12_74 = r15_72;
        if (*reinterpret_cast<uint32_t*>(&rdi67) <= 0xff && ((eax86 = g100005644, r12_74 = r15_72, !!eax86) && (*reinterpret_cast<int32_t*>(&rsi70) = static_cast<int32_t>(*reinterpret_cast<signed char*>(&rdi67)), *reinterpret_cast<int32_t*>(&rsi70 + 4) = 0, *reinterpret_cast<int32_t*>(&rdx69) = 19, *reinterpret_cast<int32_t*>(&rdx69 + 4) = 0, rdi67 = reinterpret_cast<struct s0*>(0x100004a90), rax87 = _memchr(0x100004a90, rsi70, 19, rcx68), r12_74 = r15_72, !!rax87))) {
            _putchar();
            *reinterpret_cast<uint32_t*>(&rdi67) = reinterpret_cast<uint32_t>(static_cast<int32_t>(rax87->f1));
            *reinterpret_cast<int32_t*>(&rdi67 + 4) = 0;
            _putchar();
            r14d73 = r14d73 + 2;
            goto addr_0x100004348_65;
        }
        addr_0x100004390_63:
        if (!(reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r15_72) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&r15_72) == 0))) {
            r13d88 = r14d73;
            r14d89 = *reinterpret_cast<int32_t*>(&r15_72);
            r12_90 = rbx65;
            do {
                _putchar();
                --r14d89;
            } while (r14d89);
            *reinterpret_cast<uint32_t*>(&rdi67) = v91;
            *reinterpret_cast<int32_t*>(&rdi67 + 4) = 0;
            rbx65 = r12_90;
            r14d73 = r13d88;
        }
        eax92 = _wcwidth(rdi67, rsi70, 6, rcx68);
        r14d73 = r14d73 + eax92;
        goto addr_0x100004348_65;
    }
    rax93 = ___stack_chk_guard;
    if (*rax93 != v13) {
        ___stack_chk_fail(rdi67, rsi70, rdx69, rdi67, rsi70, rdx69);
        rax94 = ___stderrp;
        rcx95 = *rax94;
        _fwrite("usage: ls [-ABCFGHLOPRSTUWabcdefghiklmnopqrstuwx1] [file ...]\n", 62, 1, rcx95);
        _exit();
    } else {
        return r14d73;
    }
    addr_0x10000407c_47:
    r15_39 = reinterpret_cast<struct s0*>(static_cast<int64_t>(*reinterpret_cast<int32_t*>(&rsi42)));
    r13_40 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp57) - 0xb0);
    while (rdi = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp57) + 0xffffffffffffff4c), rsi42 = rbx59, rdx41 = r15_39, rax96 = _mbrtowc(rdi, rsi42, rdx41, r13_40), rsp58 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp58) - 8 + 8), rax96 != 0xfffffffffffffffe) {
        if (!rax96) 
            goto addr_0x100004157_83;
        if (rax96 == 0xffffffffffffffff) {
            rbx59 = reinterpret_cast<struct s0*>(&rbx59->f1);
            r15_39 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_39) - 1);
            __asm__("xorps xmm0, xmm0");
            __asm__("movaps [rbp-0x40], xmm0");
            __asm__("movaps [rbp-0x50], xmm0");
            __asm__("movaps [rbp-0x60], xmm0");
            __asm__("movaps [rbp-0x70], xmm0");
            __asm__("movaps [rbp-0x80], xmm0");
            __asm__("movaps [rbp-0x90], xmm0");
            __asm__("movaps [rbp-0xa0], xmm0");
            __asm__("movaps [rbp-0xb0], xmm0");
            rax97 = ___stack_chk_guard;
            rax61 = *rax97;
            if (!*reinterpret_cast<int32_t*>(&r15_39)) 
                goto addr_0x10000414b_86;
        } else {
            rdi98 = reinterpret_cast<uint64_t>(static_cast<int64_t>(v99));
            if (rdi98 > 0x7f) {
                eax100 = ___maskrune();
                rsp58 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rsp58) - 8 + 8);
            } else {
                rax101 = __DefaultRuneLocale;
                eax100 = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rax101) + rdi98 * 4 + 60) & 0x40000;
            }
            if (eax100) {
            }
            rbx59 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rbx59) + reinterpret_cast<unsigned char>(rax96));
        }
    }
    addr_0x100004157_83:
    rax102 = ___stack_chk_guard;
    rax61 = *rax102;
    goto addr_0x100004161_48;
    addr_0x10000414b_86:
    goto addr_0x100004161_48;
    addr_0x100003e7a_9:
    ecx31 = v14;
    goto addr_0x100003e80_24;
}

int32_t g100005628 = 0;

struct s5* fun_100003328(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, struct s0* a8, struct s0* a9) {
    int1_t zf10;
    struct s5* rax11;

    zf10 = g100005628 == 0;
    if (zf10) {
        goto _printf;
    } else {
        _humanize_number(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8 - 13, 5, rsi, 0x100004ae8, 32, 7, 0x100005628);
        rax11 = _printf(0x100004f1c, 0x100004f1c);
        return rax11;
    }
}

int64_t _acl_get_flagset_np = 0x10000468e;

int32_t _acl_get_flagset_np(int64_t rdi) {
    goto _acl_get_flagset_np;
}

int64_t _acl_get_permset = 0x1000046ac;

int32_t _acl_get_permset(int64_t rdi) {
    goto _acl_get_permset;
}

int64_t _acl_get_qualifier = 0x1000046b6;

struct s0* _acl_get_qualifier(int64_t rdi) {
    goto _acl_get_qualifier;
}

int64_t _mbr_identifier_translate = 0x1000047e2;

int32_t _mbr_identifier_translate(int64_t rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, struct s0* a8, struct s0* a9) {
    goto _mbr_identifier_translate;
}

int64_t _uuid_unparse_upper = 0x1000048be;

void _uuid_unparse_upper(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, struct s0* a8, struct s0* a9) {
    goto _uuid_unparse_upper;
}

int64_t _acl_get_flag_np = 0x100004684;

int32_t _acl_get_flag_np(int64_t rdi, ...) {
    goto _acl_get_flag_np;
}

int64_t _acl_get_perm_np = 0x1000046a2;

int32_t _acl_get_perm_np(int64_t rdi, int64_t rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, struct s0* a8, struct s0* a9) {
    goto _acl_get_perm_np;
}

int64_t _nl_langinfo = 0x100004800;

unsigned char* _nl_langinfo(int64_t rdi) {
    goto _nl_langinfo;
}

int64_t _time = 0x1000048aa;

int64_t _time() {
    goto _time;
}

int64_t _localtime = 0x1000047ce;

int64_t _localtime(void* rdi, struct s0* rsi) {
    goto _localtime;
}

int64_t _strftime = 0x10000488c;

void _strftime(struct s0* rdi, int64_t rsi, struct s0* rdx, int64_t rcx) {
    goto _strftime;
}

int64_t _fputs = 0x100004710;

void _fputs() {
    goto _fputs;
}

int64_t _fwrite = 0x100004756;

void _fwrite(int64_t rdi, struct s0* rsi, struct s0* rdx, int64_t rcx) {
    goto _fwrite;
}

int64_t _fprintf = 0x100004706;

void _fprintf(int64_t rdi, struct s0* rsi, struct s0* rdx, ...) {
    goto _fprintf;
}

int64_t _getpid = 0x10000477e;

int32_t _getpid(int64_t rdi) {
    goto _getpid;
}

int64_t _tgoto = 0x100004616;

int64_t _tgoto(int64_t rdi) {
    goto _tgoto;
}

int64_t _memchr = 0x1000047f6;

struct s7* _memchr(struct s0* rdi, struct s0* rsi, struct s0* rdx, void* rcx) {
    goto _memchr;
}

int64_t _wcwidth = 0x1000048dc;

int32_t _wcwidth(struct s0* rdi, struct s0* rsi, struct s0* rdx, void* rcx) {
    goto _wcwidth;
}

int64_t _exit = 0x1000046f2;

void _exit() {
    goto _exit;
}

int64_t _getopt = 0x100004774;

int64_t _getopt(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    goto _getopt;
}

int64_t _ioctl = 0x1000047a6;

int32_t _ioctl(struct s0* rdi, struct s0* rsi, struct s0* rdx) {
    goto _ioctl;
}

int64_t _calloc = 0x1000046d4;

struct s0* _calloc(int64_t rdi, uint64_t rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, void* a8, void* a9, void* a10, void* a11) {
    goto _calloc;
}

int64_t _sscanf = 0x10000485a;

uint32_t _sscanf() {
    goto _sscanf;
}

int64_t _getbsize = 0x100004760;

void _getbsize(int64_t rdi, int64_t rsi) {
    goto _getbsize;
}

unsigned char g100005510 = 0;

unsigned char g100005508 = 0;

void fun_100001b54(int32_t edi, int64_t rsi, uint32_t edx) {
    unsigned char al4;
    struct s0* rdx5;
    int64_t rsi6;
    struct s0* rax7;
    struct s0* rbx8;
    struct s0* rax9;
    struct s0* rsi10;
    uint32_t eax11;
    unsigned char al12;
    struct s0* rdi13;
    struct s4* rax14;
    struct s4* r13_15;
    int32_t* rax16;
    int32_t r14d17;
    int32_t* rax18;
    int32_t* rax19;
    int64_t v20;
    uint32_t v21;
    int64_t rax22;
    int64_t rcx23;
    unsigned char al24;
    int64_t rdi25;
    struct s0* rax26;
    struct s4* rax27;

    al4 = g100005510;
    *reinterpret_cast<int32_t*>(&rdx5) = 0;
    *reinterpret_cast<int32_t*>(&rdx5 + 4) = 0;
    if (!(al4 & 1)) {
        rdx5 = reinterpret_cast<struct s0*>(0x100001e24);
    }
    *reinterpret_cast<uint32_t*>(&rsi6) = edx;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rsi6) + 4) = 0;
    rax7 = _fts_open_INODE64(rsi, rsi6, rdx5);
    rbx8 = rax7;
    if (rbx8) {
        rax9 = _fts_children_INODE64(rbx8);
        rsi10 = rax9;
        fun_100001e8c(0, rsi10, rdx5);
        eax11 = static_cast<uint32_t>(g10000550c);
        if ((eax11 & 1) == 1) {
            goto _fts_close_INODE64;
        }
        al12 = g100005508;
        if (al12 & 1) {
        }
        rdi13 = rbx8;
        rax14 = _fts_read_INODE64(rdi13, rsi10, rdx5);
        r13_15 = rax14;
        if (!r13_15) 
            goto addr_0x100001dbb_11; else 
            goto addr_0x100001c02_12;
    }
    addr_0x100001dfc_13:
    _err();
    addr_0x100001dbb_11:
    rax16 = ___error(rdi13, rsi10, rdx5, rdi13, rsi10, rdx5);
    r14d17 = *rax16;
    _fts_close_INODE64(rbx8, rsi10, rdx5);
    rax18 = ___error(rbx8, rsi10, rdx5, rbx8, rsi10, rdx5);
    *rax18 = r14d17;
    rax19 = ___error(rbx8, rsi10, rdx5, rbx8, rsi10, rdx5);
    if (*rax19) {
        goto addr_0x100001dfc_13;
    } else {
        goto v20;
    }
    addr_0x100001c02_12:
    v21 = edx & 2;
    do {
        *reinterpret_cast<uint32_t*>(&rax22) = static_cast<uint32_t>(r13_15->f88);
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax22) + 4) = 0;
        *reinterpret_cast<uint32_t*>(&rcx23) = static_cast<uint32_t>(rax22 - 1);
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx23) + 4) = 0;
        if (*reinterpret_cast<uint32_t*>(&rcx23) <= 6) 
            break;
        if (*reinterpret_cast<uint32_t*>(&rax22) == 13 && ((rsi10 = reinterpret_cast<struct s0*>(0x100004b20), al24 = _compat_mode("bin/ls", 0x100004b20, rdx5), !!v21) && !(al24 ^ 1))) {
            *reinterpret_cast<int32_t*>(&rdi25) = r13_15->f56;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi25) + 4) = 0;
            if (!*reinterpret_cast<int32_t*>(&rdi25)) {
                *reinterpret_cast<int32_t*>(&rdi25) = 2;
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi25) + 4) = 0;
            }
            rax26 = _strerror(rdi25, 0x100004b20, rdx5, rdi25, 0x100004b20, rdx5);
            rsi10 = reinterpret_cast<struct s0*>(&r13_15->f104);
            rdx5 = rax26;
            _warnx(0x100004b87, rsi10, rdx5, 0x100004b87, rsi10, rdx5);
            g100005538 = 1;
        }
        rdi13 = rbx8;
        rax27 = _fts_read_INODE64(rdi13, rsi10, rdx5);
        r13_15 = rax27;
    } while (r13_15);
    goto addr_0x100001dbb_11;
    goto *reinterpret_cast<int32_t*>(0x100001e08 + rcx23 * 4) + 0x100001e08;
}

int64_t _err = 0x1000046e8;

void _err() {
    goto _err;
}

int64_t ___maskrune = 0x100004648;

uint32_t ___maskrune() {
    goto ___maskrune;
}

int64_t _user_from_uid = 0x1000048b4;

struct s0* _user_from_uid(int64_t rdi) {
    goto _user_from_uid;
}

int64_t _group_from_gid = 0x10000479c;

struct s0* _group_from_gid(int64_t rdi) {
    goto _group_from_gid;
}

int64_t ___stack_chk_fail = 0x10000465c;

int64_t ___stack_chk_fail(struct s0* rdi, struct s0* rsi, struct s0* rdx, ...) {
    goto ___stack_chk_fail;
}

int64_t _setenv = 0x10000483c;

void _setenv(int64_t rdi, int64_t rsi, int64_t rdx) {
    goto _setenv;
}

int64_t ___assert_rtn = 0x10000462a;

void ___assert_rtn(int64_t rdi, int64_t rsi, int64_t rdx, int64_t rcx) {
    goto ___assert_rtn;
}

int64_t _readlink = 0x10000481e;

int32_t _readlink(struct s0* rdi, struct s0* rsi, struct s0* rdx, struct s0* rcx, struct s0* r8, struct s0* r9, struct s0* a7, struct s0* a8, struct s0* a9) {
    goto _readlink;
}

uint32_t g1000054f4 = 0xffffffff;

int64_t g1000055d8 = 0;

int32_t g10000564c = 0;

struct s0** ___stdoutp = reinterpret_cast<struct s0**>(0);

void fun_10000338c(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    int64_t* r15_4;
    int64_t r15_5;
    int1_t sf6;
    unsigned char* rax7;
    int1_t zf8;
    int64_t rax9;
    int1_t zf10;
    unsigned char al11;
    int64_t rdx12;
    int64_t rcx13;
    uint32_t eax14;
    int1_t zf15;
    struct s0* rax16;
    struct s0* rbx17;
    int64_t rax18;
    struct s0* r14_19;
    struct s0** rax20;
    struct s0* rsi21;
    struct s0* rdi22;
    void* eax23;
    void* ecx24;
    int32_t edi25;
    int64_t v26;

    r15_4 = ___stack_chk_guard;
    r15_5 = *r15_4;
    sf6 = reinterpret_cast<int32_t>(g1000054f4) < reinterpret_cast<int32_t>(0);
    if (sf6) {
        rax7 = _nl_langinfo(57);
        g1000054f4 = static_cast<uint32_t>(static_cast<unsigned char>(reinterpret_cast<uint1_t>(static_cast<uint32_t>(*rax7) == 100)));
    }
    zf8 = g1000055d8 == 0;
    if (zf8) {
        rax9 = _time();
        g1000055d8 = rax9;
    }
    zf10 = g10000564c == 0;
    if (zf10) {
        rsi = reinterpret_cast<struct s0*>(0x100004b20);
        al11 = _compat_mode("bin/ls", 0x100004b20, rdx, "bin/ls", 0x100004b20, rdx);
        rdx12 = rdi + 0xeff100;
        rcx13 = g1000055d8;
        if (!al11) {
            eax14 = g1000054f4;
            if (rdx12 <= rcx13 || rcx13 + 0xeff100 <= rdi) {
                addr_0x100003473_8:
                zf15 = eax14 == 0;
                rax16 = reinterpret_cast<struct s0*>(0x100004eda);
                rbx17 = reinterpret_cast<struct s0*>(0x100004ee5);
            } else {
                addr_0x100003461_9:
                zf15 = eax14 == 0;
                rax16 = reinterpret_cast<struct s0*>(0x100004ec6);
                rbx17 = reinterpret_cast<struct s0*>(0x100004ed0);
            }
        } else {
            eax14 = g1000054f4;
            if (rcx13 < rdi) 
                goto addr_0x100003473_8;
            if (rdx12 > rcx13) 
                goto addr_0x100003461_9;
            goto addr_0x100003473_8;
        }
    } else {
        zf15 = g1000054f4 == 0;
        rax16 = reinterpret_cast<struct s0*>(0x100004eac);
        rbx17 = reinterpret_cast<struct s0*>(0x100004eb9);
    }
    if (!zf15) {
        rbx17 = rax16;
    }
    rax18 = _localtime(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8 - 0x78, rsi);
    r14_19 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8 + 0xffffffffffffff90);
    _strftime(r14_19, 80, rbx17, rax18);
    rax20 = ___stdoutp;
    rsi21 = *rax20;
    rdi22 = r14_19;
    _fputs();
    if (r15_5 == r15_5) {
        return;
    }
    ___stack_chk_fail(rdi22, rsi21, rbx17, rdi22, rsi21, rbx17);
    eax23 = *reinterpret_cast<void**>(&rdi22);
    ecx24 = reinterpret_cast<void*>(reinterpret_cast<uint32_t>(eax23) & 0xf000);
    if (reinterpret_cast<int32_t>(ecx24) <= reinterpret_cast<int32_t>(0x5fff)) 
        goto addr_0x1000034e7_20;
    if (ecx24 == 0x6000) {
        edi25 = 5;
    } else {
        if (ecx24 == 0xa000) {
            fun_100003c76(1, rsi21, rbx17);
            goto addr_0x10000358c_25;
        }
        if (!reinterpret_cast<int1_t>(ecx24 == 0xc000)) 
            goto addr_0x10000354c_27; else 
            goto addr_0x10000351f_28;
    }
    addr_0x100003582_29:
    fun_100003c76(edi25, rsi21, rbx17);
    goto addr_0x10000358c_25;
    addr_0x10000351f_28:
    edi25 = 2;
    goto addr_0x100003582_29;
    addr_0x1000034e7_20:
    if (ecx24 == 0x1000) {
        edi25 = 3;
        goto addr_0x100003582_29;
    } else {
        if (ecx24 == 0x2000) {
            edi25 = 6;
            goto addr_0x100003582_29;
        } else {
            if (!reinterpret_cast<int1_t>(ecx24 == 0x4000)) {
                addr_0x10000354c_27:
                if (!(reinterpret_cast<unsigned char>(*reinterpret_cast<void**>(&eax23)) & 73)) {
                    addr_0x10000358c_25:
                    goto v26;
                } else {
                    if (reinterpret_cast<unsigned char>(*reinterpret_cast<void**>(reinterpret_cast<int64_t>(&eax23) + 1)) & 8) {
                        edi25 = 7;
                        goto addr_0x100003582_29;
                    } else {
                        if (reinterpret_cast<unsigned char>(*reinterpret_cast<void**>(reinterpret_cast<int64_t>(&eax23) + 1)) & 4) {
                            edi25 = 8;
                            goto addr_0x100003582_29;
                        } else {
                            edi25 = 4;
                            goto addr_0x100003582_29;
                        }
                    }
                }
            } else {
                if (reinterpret_cast<unsigned char>(*reinterpret_cast<void**>(&eax23)) & 2) {
                    if (reinterpret_cast<unsigned char>(*reinterpret_cast<void**>(reinterpret_cast<int64_t>(&eax23) + 1)) & 2) {
                        edi25 = 9;
                        goto addr_0x100003582_29;
                    } else {
                        edi25 = 10;
                        goto addr_0x100003582_29;
                    }
                } else {
                    edi25 = 0;
                    goto addr_0x100003582_29;
                }
            }
        }
    }
}

int64_t _acl_get_tag_type = 0x1000046c0;

int32_t _acl_get_tag_type(int64_t rdi) {
    goto _acl_get_tag_type;
}

int64_t _mbrtowc = 0x1000047ec;

struct s0* _mbrtowc(struct s0* rdi, struct s0* rsi, struct s0* rdx, void* rcx) {
    goto _mbrtowc;
}

int64_t _warn = 0x1000048c8;

void _warn() {
    goto _warn;
}

int64_t g100005608 = 0;

int64_t g1000055f0 = 0;

int64_t g1000055e0 = 0;

void fun_100003c76(int32_t edi, struct s0* rsi, struct s0* rdx) {
    int64_t rax4;
    int64_t rbx5;
    int64_t rdi6;
    int64_t rdi7;
    int64_t rax8;
    int64_t rdi9;
    int64_t rax10;

    *reinterpret_cast<int32_t*>(&rax4) = edi;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax4) + 4) = 0;
    rbx5 = rax4 + rax4 * 2;
    if (*reinterpret_cast<int32_t*>(0x100005550 + rbx5 * 4 + 8)) {
        rdi6 = g100005608;
        _tputs(rdi6, 1, fun_100003c69);
    }
    if (*reinterpret_cast<int32_t*>(0x100005550 + rbx5 * 4) != -1 && (rdi7 = g1000055f0, rax8 = _tgoto(rdi7), !!rax8)) {
        _tputs(rax8, 1, fun_100003c69);
    }
    if (*reinterpret_cast<int32_t*>(0x100005550 + rbx5 * 4 + 4) == -1 || (rdi9 = g1000055e0, rax10 = _tgoto(rdi9), rax10 == 0)) {
        return;
    } else {
        goto _tputs;
    }
}

int64_t _realloc = 0x100004828;

struct s5** _realloc(struct s5** rdi) {
    goto _realloc;
}

int64_t ___bzero = 0x100004634;

void ___bzero(struct s5** rdi) {
    goto ___bzero;
}

int64_t ___tolower = 0x100004666;

int32_t ___tolower(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    goto ___tolower;
}

int64_t _write = 0x1000048e6;

void _write(int64_t rdi, void* rsi, int64_t rdx) {
    goto _write;
}

void fun_100001a35() {
    __asm__("clc ");
}

void fun_100001a38() {
}

void fun_100001a3c() {
}

void fun_100001a40() {
}

void fun_100001a44() {
}

void fun_100001a48() {
}

void fun_100001a4c() {
}

void fun_100001a50() {
}

void fun_100001a54() {
}

void fun_100001a58() {
}

void fun_100001a5c() {
}

void fun_100001a60() {
}

void fun_100001a64() {
}

void fun_100001a68() {
}

void fun_100001a6c() {
}

void fun_100001a6f(int64_t rdi) {
    *reinterpret_cast<int32_t*>(rdi - 6) = *reinterpret_cast<int32_t*>(rdi - 6) - 1;
}

void fun_100001a73() {
    int64_t rbp1;
    int64_t rbp2;

    *reinterpret_cast<int32_t*>(rbp1 + 0x5efffff8) = *reinterpret_cast<int32_t*>(rbp2 + 0x5efffff8) - 1;
    __asm__("cli ");
}

void fun_100001a7c() {
    int1_t pf1;

    if (!pf1) 
        goto 0x100001a78;
}

void fun_100001a80() {
}

void fun_100001a84() {
}

void fun_100001a87() {
    void* rsp1;

    rsp1 = __zero_stack_offset();
    goto *reinterpret_cast<void**>(&rsp1);
}

void fun_100001a8b() {
    int32_t* rdx1;
    int32_t* rdx2;

    *rdx1 = *rdx2 + 1;
    __asm__("stc ");
}

void fun_100001a8f() {
    int64_t rbp1;

    *reinterpret_cast<int64_t*>(rbp1 + 0x3cfffffa)();
}

void fun_100001a98() {
}

void fun_100001a9c() {
}

void fun_100001a9f() {
    __asm__("cli ");
}

void fun_100001aa4() {
}

void fun_100001aa8() {
}

void fun_100001aab() {
    __asm__("sti ");
}

void fun_100001aaf() {
    __asm__("cli ");
}

void fun_100001ab4() {
}

void fun_100001ab7() {
    int32_t* rdx1;
    int32_t* rdx2;

    *rdx1 = *rdx2 + 1;
    __asm__("sti ");
}

void fun_100001abb() {
    int32_t* rsi1;
    int32_t* rsi2;

    *rsi1 = *rsi2 - 1;
    __asm__("sti ");
}

void fun_100001abf() {
    int32_t* rdx1;

    *rdx1();
    __asm__("sti ");
}

void fun_100001ac3() {
    int32_t* rcx1;

    goto *rcx1;
}

void fun_100001ac8() {
}

void fun_100001acb() {
    int64_t rsi1;
    int64_t rsi2;

    *reinterpret_cast<int32_t*>(rsi1 - 5) = *reinterpret_cast<int32_t*>(rsi2 - 5) + 1;
}

void fun_100001ad0() {
}

void fun_100001ad4() {
}

void fun_100001ad8() {
}

void fun_100001adc() {
}

void fun_100001ae0() {
}

void fun_100001ae4() {
}

void fun_100001ae8() {
}

void fun_100001aec() {
}

void fun_100001af0() {
}

void fun_100001af3(int64_t rdi) {
    *reinterpret_cast<int32_t*>(rdi - 4) = *reinterpret_cast<int32_t*>(rdi - 4) - 1;
}

void fun_100001af7(int64_t rdi) {
    int32_t* rcx2;

    rcx2[rdi * 2]();
}

void fun_100001afb() {
    int64_t rdx1;

    *reinterpret_cast<int64_t*>(rdx1 - 5)();
}

void fun_100001aff(int64_t rdi) {
    goto *reinterpret_cast<int32_t*>(rdi - 5);
}

void fun_100001b03() {
    int64_t rdx1;
    int64_t rdx2;

    *reinterpret_cast<int32_t*>(rdx1 + 0x39fffffb) = *reinterpret_cast<int32_t*>(rdx2 + 0x39fffffb) + 1;
    __asm__("stc ");
}

void fun_100001b0b() {
    int64_t rax1;

    goto *reinterpret_cast<int64_t*>(rax1 - 7);
}

void fun_100001b0f() {
    int64_t rbx1;
    int64_t rbx2;

    *reinterpret_cast<int32_t*>(rbx1 - 0x6e000007) = *reinterpret_cast<int32_t*>(rbx2 - 0x6e000007) - 1;
    __asm__("sti ");
}

void fun_100001b18() {
}

void fun_100001b1b() {
    int64_t rdx1;

    *reinterpret_cast<int32_t*>(rdx1 - 0x14000007)();
    __asm__("stc ");
}

void fun_100001b23() {
    int64_t rsi1;

    goto *reinterpret_cast<int64_t*>(rsi1 - 0x39000007);
}

void fun_100001b2b() {
    int64_t rax1;

    goto *reinterpret_cast<int64_t*>(rax1 - 0x23000005);
}

void fun_100001b33() {
    __asm__("sti ");
}

void fun_100001b38() {
    __asm__("cli ");
    __asm__("stc ");
}

void fun_100001b3b() {
    int32_t* rax1;
    int32_t* rax2;

    *rax1 = *rax2 + 1;
}

void fun_100001b3f() {
    int32_t* rsi1;
    int32_t* rsi2;

    *rsi1 = *rsi2 + 1;
    __asm__("cli ");
}

void fun_100001b43() {
    int64_t* rdx1;

    *rdx1();
    __asm__("cli ");
}

void fun_100001b47(int32_t* rdi) {
    *rdi = *rdi - 1;
}

void fun_100001b4b() {
    int32_t* rsi1;

    *rsi1();
}

void fun_100001b4f(int32_t* rdi) {
    goto *rdi;
}

struct s8 {
    signed char[72] pad72;
    int64_t f72;
};

void fun_100001b53() {
    struct s8* rbp1;

    rbp1->f72();
}

void fun_100001e0b() {
}

void fun_100001e0f(int64_t rdi) {
    *reinterpret_cast<int32_t*>(rdi + 0x22ffffff)();
}

void fun_100001e17(int64_t rdi) {
    *reinterpret_cast<int32_t*>(rdi - 0x60000001)();
}

void fun_100001e1f() {
    int64_t* rdx1;

    goto *rdx1;
}

struct s9 {
    signed char[86] pad86;
    int16_t f86;
    uint16_t f88;
};

struct s10 {
    signed char[88] pad88;
    uint16_t f88;
};

struct s11 {
    signed char[72] pad72;
    int64_t f72;
};

int64_t _strcoll = 0x100004864;

int64_t g100005528 = 0;

void fun_100001e23(struct s9** rdi, struct s10** rsi) {
    struct s11* rbp3;
    uint32_t ecx4;
    uint32_t edx5;
    uint32_t ecx6;
    uint32_t edx7;
    int1_t zf8;
    int64_t rax9;
    int64_t v10;

    rbp3->f72();
    ecx4 = static_cast<uint32_t>((*rdi)->f88);
    if (ecx4 != 7 && (edx5 = static_cast<uint32_t>((*rsi)->f88), edx5 != 7)) {
        ecx6 = static_cast<uint32_t>(*reinterpret_cast<uint16_t*>(&ecx4));
        if (ecx6 == 10 || (edx7 = static_cast<uint32_t>(*reinterpret_cast<uint16_t*>(&edx5)), edx7 == 10)) {
            goto _strcoll;
        } else {
            if (ecx6 == edx7 || ((*rdi)->f86 || ((zf8 = (g10000550c & 1) == 0, !zf8) || ecx6 != 1 && edx7 != 1))) {
                rax9 = g100005528;
                goto rax9;
            }
        }
    }
    goto v10;
}

struct s12 {
    struct s5* f0;
    signed char[20] pad28;
    int32_t f28;
    signed char[12] pad44;
    int32_t f44;
};

struct s13 {
    signed char[72] pad72;
    int64_t f72;
};

void fun_1000028e8(struct s12* rdi) {
    struct s0* rdx2;
    int32_t eax3;
    struct s13* rbp4;
    struct s12* r14_5;
    unsigned char al6;
    uint32_t ecx7;
    uint32_t ecx8;
    struct s5* rbx9;
    struct s0* rdx10;
    struct s0* rsi11;
    int64_t v12;

    __asm__("cli ");
    *reinterpret_cast<int32_t*>(&rdx2) = eax3 % *reinterpret_cast<int32_t*>(&rdi);
    *reinterpret_cast<int32_t*>(&rdx2 + 4) = 0;
    rbp4->f72();
    r14_5 = rdi;
    if (!r14_5) {
        ___assert_rtn("printscol", "/BuildRoot/Library/Caches/com.apple.xbs/Sources/file_cmds/file_cmds-264.30.2/ls/print.c", 0x85, "dp");
    } else {
        al6 = _compat_mode("bin/ls", 0x100004b20, rdx2);
        if (al6 && (r14_5->f0 && (r14_5->f0->f86 && (ecx7 = g100005650, ecx8 = ecx7 | g100005630, !!ecx8)))) {
            _printf(0x100004c73, 0x100004c73);
        }
        rbx9 = r14_5->f0;
        while (rbx9) {
            if (rbx9->f24 != 1) {
                *reinterpret_cast<int32_t*>(&rdx10) = r14_5->f28;
                *reinterpret_cast<int32_t*>(&rdx10 + 4) = 0;
                *reinterpret_cast<int32_t*>(&rsi11) = r14_5->f44;
                *reinterpret_cast<int32_t*>(&rsi11 + 4) = 0;
                fun_1000029ba(rbx9, rsi11, rdx10);
                _putchar();
            }
            rbx9 = rbx9->f16;
        }
        goto v12;
    }
}

void fun_100000f12(int64_t rdi, int64_t rsi) {
    goto 0x100004594;
}

unsigned char g100005500 = 0;

uint32_t g100005660 = 0;

int32_t* _optind = reinterpret_cast<int32_t*>(0);

unsigned char g100005520 = 0;

unsigned char g10000551c = 0;

void fun_100003bd8(int32_t edi);

unsigned char g100005524 = 0;

unsigned char g100005514 = 0;

unsigned char g100005518 = 0;

int32_t g100005610 = 0;

struct s15 {
    signed char[32] pad32;
    int64_t f32;
    int64_t f40;
};

struct s14 {
    signed char[96] pad96;
    struct s15* f96;
};

struct s17 {
    signed char[32] pad32;
    int64_t f32;
    int64_t f40;
};

struct s16 {
    signed char[96] pad96;
    struct s17* f96;
};

int64_t fun_100000fba(struct s14* rdi, struct s16* rsi);

int32_t g10000565c = 0;

struct s19 {
    signed char[64] pad64;
    int64_t f64;
    int64_t f72;
};

struct s18 {
    signed char[96] pad96;
    struct s19* f96;
};

struct s21 {
    signed char[64] pad64;
    int64_t f64;
    int64_t f72;
};

struct s20 {
    signed char[96] pad96;
    struct s21* f96;
};

int64_t fun_10000104d(struct s18* rdi, struct s20* rsi);

int32_t g100005618 = 0;

struct s23 {
    signed char[80] pad80;
    int64_t f80;
    int64_t f88;
};

struct s22 {
    signed char[96] pad96;
    struct s23* f96;
};

struct s25 {
    signed char[80] pad80;
    int64_t f80;
    int64_t f88;
};

struct s24 {
    signed char[96] pad96;
    struct s25* f96;
};

int64_t fun_10000114d(struct s22* rdi, struct s24* rsi);

struct s27 {
    signed char[48] pad48;
    int64_t f48;
    int64_t f56;
};

struct s26 {
    signed char[96] pad96;
    struct s27* f96;
};

struct s29 {
    signed char[48] pad48;
    int64_t f48;
    int64_t f56;
};

struct s28 {
    signed char[96] pad96;
    struct s29* f96;
};

int64_t fun_100000f27(struct s26* rdi, struct s28* rsi);

struct s31 {
    signed char[96] pad96;
    int64_t f96;
};

struct s30 {
    signed char[96] pad96;
    struct s31* f96;
};

struct s33 {
    signed char[96] pad96;
    int64_t f96;
};

struct s32 {
    signed char[96] pad96;
    struct s33* f96;
};

int64_t fun_1000010e0(struct s30* rdi, struct s32* rsi);

struct s35 {
    signed char[32] pad32;
    int64_t f32;
    int64_t f40;
};

struct s34 {
    signed char[96] pad96;
    struct s35* f96;
};

struct s37 {
    signed char[32] pad32;
    int64_t f32;
    int64_t f40;
};

struct s36 {
    signed char[96] pad96;
    struct s37* f96;
};

int64_t fun_100000fff(struct s34* rdi, struct s36* rsi);

struct s39 {
    signed char[64] pad64;
    int64_t f64;
    int64_t f72;
};

struct s38 {
    signed char[96] pad96;
    struct s39* f96;
};

struct s41 {
    signed char[64] pad64;
    int64_t f64;
    int64_t f72;
};

struct s40 {
    signed char[96] pad96;
    struct s41* f96;
};

int64_t fun_100001092(struct s38* rdi, struct s40* rsi);

struct s43 {
    signed char[80] pad80;
    int64_t f80;
    int64_t f88;
};

struct s42 {
    signed char[96] pad96;
    struct s43* f96;
};

struct s45 {
    signed char[80] pad80;
    int64_t f80;
    int64_t f88;
};

struct s44 {
    signed char[96] pad96;
    struct s45* f96;
};

int64_t fun_100001192(struct s42* rdi, struct s44* rsi);

struct s47 {
    signed char[48] pad48;
    int64_t f48;
    int64_t f56;
};

struct s46 {
    signed char[96] pad96;
    struct s47* f96;
};

struct s49 {
    signed char[48] pad48;
    int64_t f48;
    int64_t f56;
};

struct s48 {
    signed char[96] pad96;
    struct s49* f96;
};

int64_t fun_100000f6c(struct s46* rdi, struct s48* rsi);

struct s51 {
    signed char[96] pad96;
    int64_t f96;
};

struct s50 {
    signed char[96] pad96;
    struct s51* f96;
};

struct s53 {
    signed char[96] pad96;
    int64_t f96;
};

struct s52 {
    signed char[96] pad96;
    struct s53* f96;
};

int64_t fun_100001112(struct s50* rdi, struct s52* rsi);

void fun_100002ad5(struct s0* rdi);

struct s54 {
    struct s5* f0;
    signed char[20] pad28;
    int32_t f28;
    signed char[12] pad44;
    int32_t f44;
};

struct s5* fun_10000365b(struct s54* rdi);

struct s55 {
    struct s5* f0;
    signed char[12] pad20;
    uint32_t f20;
    uint64_t f24;
    int32_t f28;
    signed char[8] pad44;
    int32_t f44;
};

struct s5* fun_10000372d(struct s55* rdi);

void fun_100001309() {
    int64_t rdi1;
    int32_t r14d2;
    struct s0* rbx3;
    int64_t rax4;
    int64_t rcx5;
    int32_t* rax6;
    int64_t r13_7;
    struct s0* rax8;
    int32_t eax9;
    struct s0* rax10;
    struct s0* rax11;
    int64_t rbp12;
    int32_t eax13;
    int32_t r9d14;
    int1_t zf15;
    uint32_t r8d16;
    uint32_t ecx17;
    uint32_t ecx18;
    uint32_t r10d19;
    unsigned char dl20;
    uint32_t esi21;
    unsigned char r11b22;
    unsigned char r11b23;
    uint32_t eax24;
    uint32_t r12d25;
    uint32_t r12d26;
    struct s0* rax27;
    int64_t r15_28;
    int64_t rbp29;
    int64_t rax30;
    int64_t rax31;
    int64_t rax32;
    int64_t rax33;
    int64_t rax34;
    int64_t rbp35;
    int1_t zf36;
    int64_t rcx37;
    uint32_t r12d38;
    uint32_t r12d39;
    uint32_t r12d40;
    unsigned char cl41;
    uint32_t ecx42;
    unsigned char al43;
    uint32_t r15d44;
    uint32_t eax45;
    int64_t rbp46;
    uint64_t rax47;
    uint32_t eax48;
    unsigned char al49;
    int64_t rax50;
    int1_t zf51;
    int1_t zf52;
    int1_t zf53;
    unsigned char al54;
    int1_t zf55;
    int1_t zf56;
    int1_t zf57;
    uint32_t eax58;
    int1_t zf59;
    int64_t rax60;
    int1_t zf61;
    int32_t r14d62;
    int64_t rsi63;
    int64_t rbx64;
    int32_t edi65;
    int32_t r14d66;

    g100005500 = 1;
    g100005630 = 0;
    g100005660 = 0;
    while (*reinterpret_cast<int32_t*>(&rdi1) = r14d2, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi1) + 4) = 0, rax4 = _getopt(rdi1, rbx3, 0x100004af1), *reinterpret_cast<uint32_t*>(&rcx5) = static_cast<uint32_t>(rax4 - 49), *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx5) + 4) = 0, *reinterpret_cast<uint32_t*>(&rcx5) > 71) {
        if (*reinterpret_cast<int32_t*>(&rax4) == -1) 
            goto addr_0x10000168c_4;
        fun_1000043f1(rdi1, rbx3, 0x100004af1);
    }
    goto *reinterpret_cast<int32_t*>(0x100001a34 + rcx5 * 4) + 0x100001a34;
    addr_0x10000168c_4:
    rax6 = _optind;
    r13_7 = static_cast<int64_t>(*rax6);
    rax8 = _getenv(0x100004b29, rbx3, 0x100004af1);
    if (!rax8 || ((eax9 = _isatty(1, rbx3, 0x100004af1), !eax9) && (rax10 = _getenv(0x100004b32, rbx3, 0x100004af1), rax10 == 0) || (rax11 = _getenv(0x100004b41, rbx3, 0x100004af1), eax13 = _tgetent(rbp12 - 0x440, rax11, 0x100004af1), eax13 != 1))) {
        addr_0x1000017ad_7:
        r9d14 = 0;
        zf15 = g10000561c == 0;
        if (zf15) {
            addr_0x1000017ff_8:
            r8d16 = g100005630;
            ecx17 = g10000562c;
            ecx18 = ecx17 | r8d16;
            r10d19 = g100005650;
            dl20 = g100005520;
            esi21 = g100005664;
            r11b22 = g10000551c;
            r11b23 = reinterpret_cast<unsigned char>(r11b22 & 1);
            eax24 = r12d25 | 8;
            if (ecx18 | r10d19 | esi21) {
                eax24 = r12d26;
            }
        } else {
            addr_0x1000017b9_10:
            g100005638 = 1;
            _signal(2, 2);
            _signal(3, 3);
            rax27 = _getenv(0x100004b58, fun_100003bd8, 0x100004af1);
            fun_100003a4d(rax27, fun_100003bd8, 0x100004af1);
            r9d14 = g10000561c;
            goto addr_0x1000017ff_8;
        }
    } else {
        r15_28 = rbp29 - 0x648;
        rax30 = _tgetstr("AF", r15_28, 0x100004af1);
        g1000055f0 = rax30;
        rax31 = _tgetstr("AB", r15_28, 0x100004af1);
        g1000055e0 = rax31;
        rax32 = _tgetstr("me", r15_28, 0x100004af1);
        g1000055f8 = rax32;
        rax33 = _tgetstr("md", r15_28, 0x100004af1);
        g100005608 = rax33;
        rax34 = _tgetstr("op", r15_28, 0x100004af1);
        g1000055e8 = rax34;
        if (!rax34) {
            rax34 = _tgetstr("oc", rbp35 - 0x648, 0x100004af1);
            g1000055e8 = rax34;
        }
        zf36 = g1000055f0 == 0;
        if (zf36) 
            goto addr_0x1000017ad_7;
        rcx37 = g1000055e0;
        if (!rcx37) 
            goto addr_0x1000017ad_7;
        if (!rax34) 
            goto addr_0x1000017ad_7; else 
            goto addr_0x1000017a1_16;
    }
    if (dl20 & 1) {
        eax24 = r12d38;
    }
    if (r11b23) {
        eax24 = r12d39;
    }
    if (r9d14) {
        eax24 = r12d40;
    }
    cl41 = reinterpret_cast<unsigned char>(static_cast<unsigned char>(reinterpret_cast<uint1_t>(!!(ecx18 | esi21))) | g10000550c);
    ecx42 = ~static_cast<uint32_t>(cl41) & 1 | eax24;
    al43 = g100005524;
    r15d44 = ecx42 | 0x80;
    if (!(al43 & 1)) {
        r15d44 = ecx42;
    }
    if (r10d19 | r8d16) {
        eax45 = static_cast<uint32_t>(g100005514);
        if ((eax45 & 1) != 1) {
            _getbsize(rbp46 - 52, 0x100005600);
            rax47 = g100005600;
            g100005600 = reinterpret_cast<uint64_t>(reinterpret_cast<int64_t>((reinterpret_cast<uint64_t>(reinterpret_cast<int64_t>(rax47) >> 63) >> 55) + rax47) >> 9);
            r11b23 = g10000551c;
        } else {
            g100005600 = 2;
        }
    }
    eax48 = static_cast<uint32_t>(g100005518);
    if ((eax48 & 1) != 1) {
        if (!(r11b23 & 1)) {
            al49 = g100005520;
            if (!(al49 & 1)) {
                rax50 = 0x100000f00;
            } else {
                zf51 = g100005610 == 0;
                if (!zf51) {
                    rax50 = reinterpret_cast<int64_t>(fun_100000fba);
                } else {
                    zf52 = g10000565c == 0;
                    if (!zf52) {
                        rax50 = reinterpret_cast<int64_t>(fun_10000104d);
                    } else {
                        zf53 = g100005618 == 0;
                        if (!zf53) {
                            rax50 = reinterpret_cast<int64_t>(fun_10000114d);
                        } else {
                            rax50 = reinterpret_cast<int64_t>(fun_100000f27);
                        }
                    }
                }
            }
        } else {
            rax50 = reinterpret_cast<int64_t>(fun_1000010e0);
        }
    } else {
        if (!(r11b23 & 1)) {
            al54 = g100005520;
            if (!(al54 & 1)) {
                rax50 = reinterpret_cast<int64_t>(fun_100000f12);
            } else {
                zf55 = g100005610 == 0;
                if (!zf55) {
                    rax50 = reinterpret_cast<int64_t>(fun_100000fff);
                } else {
                    zf56 = g10000565c == 0;
                    if (!zf56) {
                        rax50 = reinterpret_cast<int64_t>(fun_100001092);
                    } else {
                        zf57 = g100005618 == 0;
                        if (!zf57) {
                            rax50 = reinterpret_cast<int64_t>(fun_100001192);
                        } else {
                            rax50 = reinterpret_cast<int64_t>(fun_100000f6c);
                        }
                    }
                }
            }
        } else {
            rax50 = reinterpret_cast<int64_t>(fun_100001112);
        }
    }
    g100005528 = rax50;
    eax58 = static_cast<uint32_t>(g100005500);
    if ((eax58 & 1) != 1) {
        zf59 = g100005630 == 0;
        if (!zf59) {
            rax60 = reinterpret_cast<int64_t>(fun_100002ad5);
        } else {
            zf61 = g100005660 == 0;
            if (!zf61) {
                rax60 = reinterpret_cast<int64_t>(fun_10000365b);
            } else {
                rax60 = reinterpret_cast<int64_t>(fun_10000372d);
            }
        }
    } else {
        rax60 = 0x1000028ec;
    }
    g100005530 = rax60;
    if (*reinterpret_cast<int32_t*>(&r13_7) != r14d62) {
        rsi63 = rbx64 + r13_7 * 8;
        edi65 = r14d66 - *reinterpret_cast<int32_t*>(&r13_7);
    } else {
        rsi63 = 0x1000054e0;
        edi65 = 1;
    }
    fun_100001b54(edi65, rsi63, r15d44);
    _exit();
    addr_0x1000017a1_16:
    g10000561c = 1;
    goto addr_0x1000017b9_10;
}

uint32_t g100005624 = 0;

void fun_100001394() {
    struct s0* rdx1;
    unsigned char al2;

    al2 = _compat_mode("bin/ls", 0x100004b20, rdx1);
    if (!al2) 
        goto 0x1000012db;
    g100005624 = 1;
    g100005630 = 1;
    g100005500 = 0;
    g100005660 = 0;
}

void fun_1000013bf() {
    g100005628 = 1;
    goto 0x1000012db;
}

void fun_10000142e() {
    g100005518 = 1;
    goto 0x1000012db;
}

void fun_1000014f7() {
    struct s0* rdx1;
    unsigned char al2;

    al2 = _compat_mode("bin/ls", 0x100004b20, rdx1);
    if (al2) {
    }
    goto 0x1000012db;
}

void fun_100001526() {
    goto 0x1000012db;
}

void fun_100001a89() {
    __asm__("clc ");
}

void fun_100001ac5() {
    __asm__("sti ");
}

void fun_100001b29() {
    __asm__("stc ");
}

void fun_100001b31() {
    __asm__("sti ");
}

void fun_100001b51() {
    __asm__("cli ");
}

void fun_100001c2a() {
}

struct s56 {
    signed char[86] pad86;
    int16_t f86;
};

struct s57 {
    signed char[104] pad104;
    unsigned char f104;
};

void fun_100001c91() {
    struct s56* r13_1;
    struct s57* r13_2;
    int1_t zf3;
    uint32_t eax4;
    int64_t rbp5;
    struct s0* rbx6;
    struct s0* rax7;
    struct s0* r14_8;
    struct s0* rdx9;
    unsigned char al10;
    int64_t rbp11;
    struct s0* rax12;
    struct s0* r13_13;
    struct s0* rdx14;
    unsigned char al15;
    int64_t rbx16;
    int64_t r13_17;

    if (!r13_1->f86 || (static_cast<uint32_t>(r13_2->f104) != 46 || (zf3 = (g100005504 & 1) == 0, !zf3))) {
        eax4 = static_cast<uint32_t>(g10000553c);
        if ((eax4 & 1) != 1) {
            if (*reinterpret_cast<int32_t*>(rbp5 - 52) >= 2) {
                _printf(0x100004b94, 0x100004b94);
                g10000553c = 1;
            }
        } else {
            _printf(0x100004b8e, 0x100004b8e);
        }
        rax7 = _fts_children_INODE64(rbx6, rbx6);
        r14_8 = rax7;
        al10 = _compat_mode("bin/ls", 0x100004b20, rdx9);
        if (*reinterpret_cast<int32_t*>(rbp11 - 44) && (!(al10 ^ 1) && (rax12 = r14_8, !!r14_8))) {
            do {
                if (static_cast<uint32_t>(*reinterpret_cast<uint16_t*>(reinterpret_cast<unsigned char>(rax12) + 88)) == 13) {
                    rax12->f24 = reinterpret_cast<struct s0*>(1);
                }
                rax12 = rax12->f16;
            } while (rax12);
        }
        fun_100001e8c(r13_13, r14_8, rdx14);
        if (!r14_8) 
            goto 0x100001da7;
        al15 = g100005508;
        if (!(reinterpret_cast<unsigned char>(al15 ^ 1) & 1)) 
            goto 0x100001da7;
    }
    _fts_set_INODE64(rbx16, r13_17, 4);
}

struct s58 {
    signed char[104] pad104;
    struct s0* f104;
};

void fun_100001cd3() {
    struct s58* r13_1;
    struct s0* rdx2;
    struct s0* rdx3;
    unsigned char al4;

    _warnx(0x100004b6a, &r13_1->f104, rdx2);
    al4 = _compat_mode("bin/ls", 0x100004b20, rdx3);
    if (!al4) 
        goto 0x100001da7; else 
        goto "???";
}

void fun_10000206d() {
    int64_t rbp1;
    int64_t rbp2;
    int64_t rbp3;
    int64_t rbp4;
    int64_t rbp5;
    int64_t rbp6;
    int64_t rbp7;
    int64_t rbp8;
    int64_t rbp9;
    int1_t zf10;

    *reinterpret_cast<int64_t*>(rbp1 - 0x4e0) = 0;
    *reinterpret_cast<int64_t*>(rbp2 - 0x4c0) = 0;
    *reinterpret_cast<int64_t*>(rbp3 - 0x4d0) = 0;
    *reinterpret_cast<int32_t*>(rbp4 - 0x4ec) = 0;
    *reinterpret_cast<int32_t*>(rbp5 - 0x4e8) = 0;
    *reinterpret_cast<int32_t*>(rbp6 - 0x4e4) = 0;
    *reinterpret_cast<int64_t*>(rbp7 - 0x4b8) = 0;
    *reinterpret_cast<int64_t*>(rbp8 - 0x4c8) = 0;
    *reinterpret_cast<int64_t*>(rbp9 - 0x4d8) = 0;
    zf10 = g10000561c == 0;
    if (!zf10) 
        goto 0x1000020e0;
    g100005638 = 0;
}

void fun_1000028e1(int32_t edi) {
    goto edi;
}

int32_t g100005648 = 0;

struct s59 {
    signed char[4294988448] pad4294988448;
    uint32_t f4294988448;
};

struct s60 {
    signed char[4294988880] pad4294988880;
    uint32_t f4294988880;
};

void fun_100002ad5(struct s0* rdi) {
    void* rbp2;
    struct s0* r15_3;
    struct s0* v4;
    int64_t* rax5;
    int64_t v6;
    struct s0* r14_7;
    uint32_t ecx8;
    struct s0* rcx9;
    struct s0* rdx10;
    void* rax11;
    struct s0* rsi12;
    int64_t* rax13;
    void* r12_14;
    int32_t v15;
    struct s3* rbx16;
    int1_t zf17;
    int1_t zf18;
    uint64_t rdx19;
    void* rax20;
    int64_t rdi21;
    struct s0* r8_22;
    struct s0* r9_23;
    struct s0* v24;
    struct s0* v25;
    struct s0* v26;
    struct s0* v27;
    uint32_t edx28;
    int32_t eax29;
    struct s0* rdx30;
    struct s0* eax31;
    struct s0* rdi32;
    int1_t zf33;
    int1_t zf34;
    int1_t zf35;
    int1_t zf36;
    int64_t rdi37;
    int1_t zf38;
    uint32_t edi39;
    int32_t eax40;
    struct s0* r15_41;
    int32_t eax42;
    int64_t rdi43;
    int64_t rdi44;
    struct s0* v45;
    int1_t zf46;
    uint32_t edi47;
    uint32_t eax48;
    struct s3* v49;
    struct s0* r14_50;
    struct s0* rdi51;
    struct s0* rbx52;
    int32_t eax53;
    int64_t* rax54;
    int64_t r14_55;
    int32_t* rax56;
    int64_t rdi57;
    struct s0* rax58;
    int32_t r12d59;
    struct s0* r15_60;
    int32_t eax61;
    struct s0* r13_62;
    struct s0* rbx63;
    struct s0* rdi64;
    struct s0* rax65;
    struct s0* rax66;
    struct s0* v67;
    int32_t eax68;
    struct s0* rbx69;
    int32_t eax70;
    uint32_t r12d71;
    int32_t r14d72;
    struct s0* rsi73;
    int32_t eax74;
    int32_t eax75;
    int32_t eax76;
    struct s0* rax77;
    int32_t eax78;
    struct s0* rax79;
    int1_t zf80;
    int32_t eax81;
    struct s0* rsi82;
    struct s0* rbx83;
    int32_t v84;
    int64_t v85;
    int32_t eax86;
    int64_t r13_87;
    struct s0* rsi88;
    struct s0* rdx89;
    struct s59* rbx90;
    int64_t rsi91;
    int64_t v92;
    int32_t eax93;
    struct s60* r15_94;
    int64_t v95;
    int32_t eax96;
    int32_t v97;

    rbp2 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8);
    r15_3 = rdi;
    v4 = r15_3;
    rax5 = ___stack_chk_guard;
    v6 = *rax5;
    r14_7 = *reinterpret_cast<struct s0**>(&r15_3->f0);
    if (*reinterpret_cast<int16_t*>(reinterpret_cast<unsigned char>(r14_7) + 86) && (ecx8 = g100005650, *reinterpret_cast<unsigned char*>(&rcx9) = reinterpret_cast<unsigned char>(ecx8 | g100005630), *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0, !!*reinterpret_cast<unsigned char*>(&rcx9))) {
        rdx10 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r15_3->f8) % g100005600);
        rax11 = reinterpret_cast<void*>(reinterpret_cast<unsigned char>(r15_3->f8) / g100005600);
        rcx9 = reinterpret_cast<struct s0*>(reinterpret_cast<uint64_t>(rax11) - (1 - static_cast<uint64_t>(reinterpret_cast<uint1_t>(reinterpret_cast<uint64_t>(rax11) < 1 - static_cast<uint64_t>(reinterpret_cast<uint1_t>(reinterpret_cast<unsigned char>(rdx10) < reinterpret_cast<unsigned char>(1)))))));
        rdi = reinterpret_cast<struct s0*>(0x100004c73);
        rsi12 = rcx9;
        _printf(0x100004c73, 0x100004c73);
        r14_7 = *reinterpret_cast<struct s0**>(&r15_3->f0);
    }
    if (!r14_7) {
        addr_0x1000032ee_4:
        rax13 = ___stack_chk_guard;
        if (*rax13 == v6) {
            return;
        }
    } else {
        r12_14 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp2) - 0x870);
        v15 = 0;
        while (1) {
            if (r14_7->f24 == 1) {
                addr_0x1000032e1_8:
                r14_7 = r14_7->f16;
                if (r14_7) 
                    continue; else 
                    goto addr_0x1000032ee_4;
            } else {
                rbx16 = *reinterpret_cast<struct s3**>(reinterpret_cast<unsigned char>(r14_7) + 96);
                zf17 = g10000562c == 0;
                if (!zf17) {
                    rdx10 = rbx16->f8;
                    _printf(0x100004c7e, 0x100004c7e);
                }
                zf18 = g100005650 == 0;
                if (!zf18) {
                    rdx19 = reinterpret_cast<uint64_t>(reinterpret_cast<int64_t>(rbx16->f104) % reinterpret_cast<int64_t>(g100005600));
                    rax20 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbx16->f104) / reinterpret_cast<int64_t>(g100005600));
                    rcx9 = reinterpret_cast<struct s0*>(reinterpret_cast<uint64_t>(rax20) - (1 - static_cast<uint64_t>(reinterpret_cast<uint1_t>(reinterpret_cast<uint64_t>(rax20) < 1 - static_cast<uint64_t>(reinterpret_cast<uint1_t>(rdx19 < 1))))));
                    rdx10 = rcx9;
                    _printf(0x100004c85, 0x100004c85);
                }
                *reinterpret_cast<uint32_t*>(&rdi21) = static_cast<uint32_t>(rbx16->f4);
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi21) + 4) = 0;
                _strmode(rdi21, r12_14, rdx10, rcx9, r8_22, r9_23, v24, v25, v26);
                v27 = r14_7->f32;
                edx28 = g100005624;
                eax29 = g100005648;
                *reinterpret_cast<uint32_t*>(&r8_22) = static_cast<uint32_t>(rbx16->f6);
                *reinterpret_cast<int32_t*>(&r8_22 + 4) = 0;
                if (!edx28) 
                    goto addr_0x100002c44_14;
                if (eax29) 
                    goto addr_0x100002c2a_16;
            }
            addr_0x100002c44_14:
            if (!edx28) {
                r9_23 = *reinterpret_cast<struct s0**>(reinterpret_cast<unsigned char>(r15_3) + 56);
                *reinterpret_cast<int32_t*>(&r9_23 + 4) = 0;
                rdx30 = *reinterpret_cast<struct s0**>(&v27->f0);
                if (!eax29) {
                    eax31 = r15_3->f40;
                    v26 = v27->f8;
                    v25 = eax31;
                    v24 = rdx30;
                    rdi32 = reinterpret_cast<struct s0*>(0x100004ca7);
                } else {
                    v24 = rdx30;
                    goto addr_0x100002c77_20;
                }
            } else {
                r9_23 = r15_3->f40;
                *reinterpret_cast<int32_t*>(&r9_23 + 4) = 0;
                v24 = v27->f8;
                goto addr_0x100002c77_20;
            }
            addr_0x100002c80_22:
            rdx10 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff776);
            _printf(rdi32, rdi32);
            addr_0x100002c8f_23:
            zf33 = g100005620 == 0;
            if (!zf33) {
                rdx10 = v27->f16;
                _printf(0x100004cbd, 0x100004cbd);
            }
            *reinterpret_cast<unsigned char*>(&rcx9) = reinterpret_cast<unsigned char>(0x4000);
            *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0;
            if (((rbx16->f4 | reinterpret_cast<unsigned char>(0x4000)) & 0xf000) != 0x6000) {
                *reinterpret_cast<unsigned char*>(&rcx9) = r15_3->f52;
                *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0;
                r8_22 = rbx16->f96;
                if (!r15_3->f16) {
                    rsi12 = r8_22;
                    fun_100003328(rcx9, rsi12, rdx10, rcx9, r8_22, r9_23, v24, v25, v26);
                } else {
                    *reinterpret_cast<uint32_t*>(&rsi12) = 8 - *reinterpret_cast<unsigned char*>(&rcx9);
                    *reinterpret_cast<int32_t*>(&rsi12 + 4) = 0;
                    rdx10 = reinterpret_cast<struct s0*>(0x100004ae8);
                    _printf(0x100004cda, 0x100004cda);
                }
            } else {
                *reinterpret_cast<uint32_t*>(&rdx10) = rbx16->f24 & 0xffffff;
                *reinterpret_cast<int32_t*>(&rdx10 + 4) = 0;
                *reinterpret_cast<uint32_t*>(&rsi12) = rbx16->f24 >> 24;
                *reinterpret_cast<int32_t*>(&rsi12 + 4) = 0;
                if (*reinterpret_cast<uint32_t*>(&rdx10) < 0x100) {
                    _printf(0x100004cd0);
                } else {
                    _printf(0x100004cc3);
                }
            }
            zf34 = g100005610 == 0;
            if (zf34) {
                zf35 = g10000565c == 0;
                if (zf35) {
                    zf36 = g100005618 == 0;
                    if (zf36) {
                        rdi37 = rbx16->f48;
                    } else {
                        rdi37 = rbx16->f80;
                    }
                } else {
                    rdi37 = rbx16->f64;
                }
            } else {
                rdi37 = rbx16->f32;
            }
            fun_10000338c(rdi37, rsi12, rdx10);
            zf38 = g10000561c == 0;
            if (!zf38) {
                edi39 = static_cast<uint32_t>(rbx16->f4);
                eax40 = fun_1000034cf(edi39, rsi12, rdx10);
                v15 = eax40;
            }
            r15_41 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r14_7) + 0x68);
            fun_100003595(r15_41, rsi12, rdx10);
            if (v15 && (eax42 = g10000561c, !!eax42)) {
                rdi43 = g1000055e8;
                _tputs(rdi43, 1, fun_100003c69);
                rdi44 = g1000055f8;
                *reinterpret_cast<uint32_t*>(&rsi12) = 1;
                *reinterpret_cast<int32_t*>(&rsi12 + 4) = 0;
                rdx10 = reinterpret_cast<struct s0*>(fun_100003c69);
                rbx16 = rbx16;
                _tputs(rdi44, 1, fun_100003c69);
            }
            v45 = r14_7;
            zf46 = g100005664 == 0;
            if (!zf46) {
                edi47 = static_cast<uint32_t>(rbx16->f4);
                fun_1000035cb(edi47, rsi12, rdx10);
            }
            eax48 = static_cast<uint32_t>(rbx16->f4);
            v49 = rbx16;
            r14_50 = v27;
            if ((eax48 & 0xf000) == 0xa000) {
                if (!*reinterpret_cast<int16_t*>(reinterpret_cast<unsigned char>(v45) + 86)) {
                    *reinterpret_cast<unsigned char*>(&rcx9) = reinterpret_cast<unsigned char>(0x401);
                    *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0;
                    rdi51 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0);
                    r8_22 = reinterpret_cast<struct s0*>(0x100004f07);
                    r9_23 = r15_41;
                } else {
                    r9_23 = v45->f8->f40;
                    v24 = r15_41;
                    *reinterpret_cast<unsigned char*>(&rcx9) = reinterpret_cast<unsigned char>(0x401);
                    *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0;
                    rdi51 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0);
                    r8_22 = reinterpret_cast<struct s0*>(0x100004bfb);
                }
                ___snprintf_chk(rdi51, 0x401, rdi51, 0x401);
                *reinterpret_cast<uint32_t*>(&rdx10) = 0x400;
                *reinterpret_cast<int32_t*>(&rdx10 + 4) = 0;
                rbx52 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff7b0);
                rsi12 = rbx52;
                eax53 = _readlink(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0, rsi12, 0x400, 0x401, r8_22, r9_23, v24, v25, v26);
                if (eax53 == -1) {
                    rax54 = ___stderrp;
                    r14_55 = *rax54;
                    rax56 = ___error(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0, rsi12, 0x400, reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0, rsi12, 0x400);
                    *reinterpret_cast<int32_t*>(&rdi57) = *rax56;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi57) + 4) = 0;
                    rax58 = _strerror(rdi57, rsi12, 0x400, rdi57, rsi12, 0x400);
                    rcx9 = rax58;
                    rsi12 = reinterpret_cast<struct s0*>(0x100004f0a);
                    rdx10 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0);
                    _fprintf(r14_55, 0x100004f0a, rdx10, r14_55, 0x100004f0a, rdx10);
                } else {
                    *reinterpret_cast<signed char*>(reinterpret_cast<int64_t>(rbp2) + eax53 - 0x850) = 0;
                    _printf(0x100004f17, 0x100004f17);
                    fun_100003595(rbx52, rsi12, 0x400, rbx52, rsi12, 0x400);
                }
                r14_50 = r14_50;
            }
            *reinterpret_cast<int32_t*>(&rdi) = 10;
            *reinterpret_cast<int32_t*>(&rdi + 4) = 0;
            _putchar();
            r12d59 = r14_50->f48;
            r15_60 = r15_3;
            if (r12d59 && ((eax61 = g100005668, !!eax61) && !(reinterpret_cast<uint1_t>(r12d59 < 0) | reinterpret_cast<uint1_t>(r12d59 == 0)))) {
                r13_62 = r14_50->f32;
                rbx63 = r14_50->f24;
                do {
                    _putchar();
                    fun_100003595(rbx63, rsi12, rdx10, rbx63, rsi12, rdx10);
                    _putchar();
                    *reinterpret_cast<unsigned char*>(&rdi64) = r15_60->f52;
                    *reinterpret_cast<int32_t*>(&rdi64 + 4) = 0;
                    rsi12 = reinterpret_cast<struct s0*>(static_cast<int64_t>(reinterpret_cast<int32_t>(*reinterpret_cast<struct s0**>(&r13_62->f0))));
                    fun_100003328(rdi64, rsi12, rdx10, rcx9, r8_22, r9_23, v24, v25, v26);
                    _putchar();
                    rdi = rbx63;
                    rax65 = _strlen(rdi, rsi12, rdi, rsi12);
                    rbx63 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(rax65) + reinterpret_cast<unsigned char>(rbx63) + 1);
                    r13_62 = reinterpret_cast<struct s0*>(reinterpret_cast<unsigned char>(r13_62) + 4);
                    --r12d59;
                } while (r12d59);
            }
            rax66 = r14_50->f40;
            v67 = rax66;
            if (rax66 && ((eax68 = g100005614, !!eax68) && (*reinterpret_cast<uint16_t*>(&r14_50) = v49->f4, *reinterpret_cast<uint32_t*>(&rsi12) = 0, *reinterpret_cast<int32_t*>(&rsi12 + 4) = 0, rdi = v67, rbx69 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff7b0), rdx10 = rbx69, eax70 = _acl_get_entry(rdi, rdi), !eax70))) {
                r12d71 = static_cast<unsigned char>(reinterpret_cast<uint1_t>((*reinterpret_cast<uint32_t*>(&r14_50) & 0xf000) != 0x4000)) + 1;
                r14d72 = 0;
                while (1) {
                    rsi73 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff788);
                    eax74 = _acl_get_tag_type(0);
                    if (eax74 || ((rsi73 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff780), eax75 = _acl_get_flagset_np(0), !!eax75) || ((rsi73 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff778), eax76 = _acl_get_permset(0), !!eax76) || (rax77 = _acl_get_qualifier(0), rax77 == 0)))) {
                        addr_0x1000032a9_59:
                        ++r14d72;
                        *reinterpret_cast<uint32_t*>(&rsi12) = *reinterpret_cast<uint32_t*>(&rsi73) - (*reinterpret_cast<uint32_t*>(&rsi73) + reinterpret_cast<uint1_t>(*reinterpret_cast<uint32_t*>(&rsi73) < *reinterpret_cast<uint32_t*>(&rsi73)));
                        *reinterpret_cast<int32_t*>(&rsi12 + 4) = 0;
                        rdi = v67;
                        rdx10 = rbx69;
                        eax78 = _acl_get_entry(rdi, rdi);
                        if (!eax78) 
                            continue; else 
                            break;
                    } else {
                        rax79 = _malloc(0x105, 0x105);
                        if (!rax79) 
                            goto addr_0x100003310_61;
                        zf80 = g10000563c == 0;
                        if (!zf80) 
                            goto addr_0x10000313a_63;
                        *reinterpret_cast<uint32_t*>(&rdx10) = 16;
                        *reinterpret_cast<int32_t*>(&rdx10 + 4) = 0;
                        *reinterpret_cast<unsigned char*>(&rcx9) = reinterpret_cast<unsigned char>(31);
                        *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0;
                        r8_22 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffffbc0);
                        r9_23 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff78c);
                        eax81 = _mbr_identifier_translate(6, rax77, 16, 31, r8_22, r9_23, v24, v25, v26);
                        if (!eax81) 
                            goto addr_0x100003022_65;
                    }
                    addr_0x10000313a_63:
                    rsi82 = rax79;
                    _uuid_unparse_upper(rax77, rsi82, rdx10, rcx9, r8_22, r9_23, v24, v25, v26);
                    addr_0x100003145_66:
                    _acl_free(rax77, rsi82, rdx10, rcx9, r8_22, r9_23, v24, rax77, rsi82, rdx10, rcx9, r8_22, r9_23, v24);
                    rbx83 = reinterpret_cast<struct s0*>(0x100004d98);
                    if (v84 == 2) {
                        rbx83 = reinterpret_cast<struct s0*>(0x100004d93);
                    }
                    if (v84 == 1) {
                        rbx83 = reinterpret_cast<struct s0*>(0x100004d8d);
                    }
                    eax86 = _acl_get_flag_np(v85, v85);
                    rcx9 = reinterpret_cast<struct s0*>(0x100004ae8);
                    if (eax86) {
                        rcx9 = reinterpret_cast<struct s0*>(0x100004dae);
                    }
                    *reinterpret_cast<int32_t*>(&r13_87) = 0;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r13_87) + 4) = 0;
                    *reinterpret_cast<int32_t*>(&rsi88) = r14d72;
                    *reinterpret_cast<int32_t*>(&rsi88 + 4) = 0;
                    rdx89 = rax79;
                    r8_22 = rbx83;
                    _printf(0x100004da0, 0x100004da0);
                    _free(rax79, rsi88, rdx89, rcx9, r8_22, r9_23, v24, rax79, rsi88, rdx89, rcx9, r8_22, r9_23, v24);
                    *reinterpret_cast<int32_t*>(&rbx90) = 16;
                    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rbx90) + 4) = 0;
                    do {
                        *reinterpret_cast<int32_t*>(&rsi91) = *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(rbx90) + 0x1000052a0 - 16);
                        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rsi91) + 4) = 0;
                        eax93 = _acl_get_perm_np(v92, rsi91, rdx89, rcx9, r8_22, r9_23, v24, v25, v26);
                        if (eax93 && *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(rbx90) + 0x1000052a0) & r12d71) {
                            rcx9 = reinterpret_cast<struct s0*>(0x100004dbe);
                            if (*reinterpret_cast<int32_t*>(&r13_87)) {
                            }
                            rdx89 = *reinterpret_cast<struct s0**>(reinterpret_cast<int64_t>(rbx90) + 0x1000052a0 - 8);
                            _printf(0x100004db9, 0x100004db9);
                            *reinterpret_cast<int32_t*>(&r13_87) = static_cast<int32_t>(r13_87 + 1);
                            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r13_87) + 4) = 0;
                        }
                        rbx90 = reinterpret_cast<struct s59*>(reinterpret_cast<int64_t>(rbx90) + 24);
                        *reinterpret_cast<int32_t*>(&r15_94) = 16;
                        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r15_94) + 4) = 0;
                    } while (!reinterpret_cast<int1_t>(rbx90 == 0x1a8));
                    do {
                        *reinterpret_cast<uint32_t*>(&rsi73) = *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(r15_94) + reinterpret_cast<int64_t>(" ") - 16);
                        eax96 = _acl_get_flag_np(v95);
                        if (eax96 && *reinterpret_cast<uint32_t*>(reinterpret_cast<int64_t>(r15_94) + reinterpret_cast<int64_t>(" ")) & r12d71) {
                            rsi73 = reinterpret_cast<struct s0*>(0x100004ae8);
                            rcx9 = reinterpret_cast<struct s0*>(0x100004dbe);
                            if (*reinterpret_cast<int32_t*>(&r13_87)) {
                                rsi73 = reinterpret_cast<struct s0*>(0x100004dbe);
                            }
                            _printf(0x100004db9, 0x100004db9);
                            *reinterpret_cast<int32_t*>(&r13_87) = static_cast<int32_t>(r13_87 + 1);
                            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r13_87) + 4) = 0;
                        }
                        r15_94 = reinterpret_cast<struct s60*>(reinterpret_cast<int64_t>(r15_94) + 24);
                    } while (!reinterpret_cast<int1_t>(r15_94 == 0x70));
                    _putchar();
                    rbx69 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff7b0);
                    goto addr_0x1000032a9_59;
                    addr_0x100003022_65:
                    r9_23 = reinterpret_cast<struct s0*>(0x100004dcb);
                    if (v97 == 1) {
                        r9_23 = reinterpret_cast<struct s0*>(0x100004dc6);
                    }
                    v24 = reinterpret_cast<struct s0*>(0);
                    *reinterpret_cast<int32_t*>(&rsi82) = 0x105;
                    *reinterpret_cast<int32_t*>(&rsi82 + 4) = 0;
                    *reinterpret_cast<uint32_t*>(&rdx10) = 0;
                    *reinterpret_cast<int32_t*>(&rdx10 + 4) = 0;
                    *reinterpret_cast<unsigned char*>(&rcx9) = reinterpret_cast<unsigned char>(0x105);
                    *reinterpret_cast<int32_t*>(&rcx9 + 4) = 0;
                    r8_22 = reinterpret_cast<struct s0*>(0x100004dc0);
                    ___snprintf_chk(rax79, 0x105, rax79, 0x105);
                    _free(0, 0x105, 0, 0x105, 0x100004dc0, r9_23, 0, 0, 0x105, 0, 0x105, 0x100004dc0, r9_23, 0);
                    goto addr_0x100003145_66;
                }
            }
            r15_3 = v4;
            r14_7 = v45;
            r12_14 = reinterpret_cast<void*>(reinterpret_cast<int64_t>(rbp2) - 0x870);
            goto addr_0x1000032e1_8;
            addr_0x100002c77_20:
            rdi32 = reinterpret_cast<struct s0*>(0x100004c97);
            goto addr_0x100002c80_22;
            addr_0x100002c2a_16:
            rdx10 = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(rbp2) + 0xfffffffffffff776);
            _printf(0x100004c8b, 0x100004c8b);
            goto addr_0x100002c8f_23;
        }
    }
    addr_0x100003323_87:
    ___stack_chk_fail(rdi, rsi12, rdx10, rdi, rsi12, rdx10);
    addr_0x100003310_61:
    rsi12 = reinterpret_cast<struct s0*>(0x100004baf);
    *reinterpret_cast<int32_t*>(&rdi) = 1;
    *reinterpret_cast<int32_t*>(&rdi + 4) = 0;
    _err();
    goto addr_0x100003323_87;
}

uint32_t g1000054d0 = 80;

struct s5* fun_10000365b(struct s54* rdi) {
    struct s54* r14_2;
    struct s5* rbx3;
    struct s5* rax4;
    int32_t r12d5;
    struct s0* rdi6;
    struct s0* rsi7;
    struct s0* rax8;
    int64_t rax9;
    uint64_t rcx10;
    struct s0* rdx11;
    struct s5** rbx12;

    r14_2 = rdi;
    rbx3 = r14_2->f0;
    if (!rbx3) {
        addr_0x10000371e_2:
        return rax4;
    } else {
        r12d5 = 0;
        do {
            if (rbx3->f24 != 1) {
                rdi6 = reinterpret_cast<struct s0*>(&rbx3->f104);
                rax8 = _strlen(rdi6, rsi7, rdi6, rsi7);
                *reinterpret_cast<uint32_t*>(&rax9) = static_cast<uint32_t>(static_cast<unsigned char>(reinterpret_cast<uint1_t>(!!rbx3->f16)));
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax9) + 4) = 0;
                *reinterpret_cast<uint32_t*>(&rcx10) = g1000054d0;
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx10) + 4) = 0;
                if (static_cast<int64_t>(r12d5) + reinterpret_cast<unsigned char>(rax8) + reinterpret_cast<uint64_t>(rax9 * 2) >= rcx10) {
                    _putchar();
                    r12d5 = 0;
                }
                *reinterpret_cast<int32_t*>(&rdx11) = r14_2->f28;
                *reinterpret_cast<int32_t*>(&rdx11 + 4) = 0;
                *reinterpret_cast<int32_t*>(&rsi7) = r14_2->f44;
                *reinterpret_cast<int32_t*>(&rsi7 + 4) = 0;
                rax4 = fun_1000029ba(rbx3, rsi7, rdx11);
                r12d5 = *reinterpret_cast<int32_t*>(&rax4) + r12d5;
                rbx12 = &rbx3->f16;
                if (rbx3->f16) {
                    rax4 = _printf(0x100004ce3, 0x100004ce3);
                    r12d5 = r12d5 + 2;
                }
            } else {
                rbx12 = &rbx3->f16;
            }
            rbx3 = *rbx12;
        } while (rbx3);
        if (!r12d5) 
            goto addr_0x10000371e_2;
    }
    goto _putchar;
}

int64_t fun_100003c42(signed char dil);

int64_t _kill = 0x1000047ba;

void fun_100003bd8(int32_t edi) {
    int64_t rdi2;
    struct s0* rbx3;
    int64_t rdi4;
    int64_t rdi5;

    rdi2 = g1000055e8;
    rbx3 = reinterpret_cast<struct s0*>(fun_100003c69);
    if (edi) {
        rbx3 = reinterpret_cast<struct s0*>(fun_100003c42);
    }
    _tputs(rdi2, 1, rbx3);
    rdi4 = g1000055f8;
    _tputs(rdi4, 1, rbx3);
    *reinterpret_cast<int32_t*>(&rdi5) = edi;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rdi5) + 4) = 0;
    _signal(rdi5);
    _getpid(rdi5);
    goto _kill;
}

int64_t fun_100003c42(signed char dil) {
    _write(1, reinterpret_cast<int64_t>(__zero_stack_offset()) - 8 - 1, 1);
    return 0;
}

int64_t fun_100000f27(struct s26* rdi, struct s28* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = 1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f48 <= rdi->f96->f48) {
        if (rsi->f96->f48 >= rdi->f96->f48) {
            if (rsi->f96->f56 <= rdi->f96->f56 && (*reinterpret_cast<int32_t*>(&rax3) = -1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f56 >= rdi->f96->f56)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = -1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_100000f6c(struct s46* rdi, struct s48* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = -1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f48 <= rdi->f96->f48) {
        if (rsi->f96->f48 >= rdi->f96->f48) {
            if (rsi->f96->f56 <= rdi->f96->f56 && (*reinterpret_cast<int32_t*>(&rax3) = 1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f56 >= rdi->f96->f56)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = 1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_100000fba(struct s14* rdi, struct s16* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = 1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f32 <= rdi->f96->f32) {
        if (rsi->f96->f32 >= rdi->f96->f32) {
            if (rsi->f96->f40 <= rdi->f96->f40 && (*reinterpret_cast<int32_t*>(&rax3) = -1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f40 >= rdi->f96->f40)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = -1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_100000fff(struct s34* rdi, struct s36* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = -1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f32 <= rdi->f96->f32) {
        if (rsi->f96->f32 >= rdi->f96->f32) {
            if (rsi->f96->f40 <= rdi->f96->f40 && (*reinterpret_cast<int32_t*>(&rax3) = 1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f40 >= rdi->f96->f40)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = 1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_10000104d(struct s18* rdi, struct s20* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = 1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f64 <= rdi->f96->f64) {
        if (rsi->f96->f64 >= rdi->f96->f64) {
            if (rsi->f96->f72 <= rdi->f96->f72 && (*reinterpret_cast<int32_t*>(&rax3) = -1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f72 >= rdi->f96->f72)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = -1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_100001092(struct s38* rdi, struct s40* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = -1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f64 <= rdi->f96->f64) {
        if (rsi->f96->f64 >= rdi->f96->f64) {
            if (rsi->f96->f72 <= rdi->f96->f72 && (*reinterpret_cast<int32_t*>(&rax3) = 1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f72 >= rdi->f96->f72)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = 1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_1000010e0(struct s30* rdi, struct s32* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = 1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f96 > rdi->f96->f96 || (*reinterpret_cast<int32_t*>(&rax3) = -1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f96 < rdi->f96->f96)) {
        return rax3;
    } else {
        goto 0x100004594;
    }
}

int64_t fun_100001112(struct s50* rdi, struct s52* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = -1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f96 > rdi->f96->f96 || (*reinterpret_cast<int32_t*>(&rax3) = 1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f96 < rdi->f96->f96)) {
        return rax3;
    } else {
        goto 0x100004594;
    }
}

int64_t fun_10000114d(struct s22* rdi, struct s24* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = 1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f80 <= rdi->f96->f80) {
        if (rsi->f96->f80 >= rdi->f96->f80) {
            if (rsi->f96->f88 <= rdi->f96->f88 && (*reinterpret_cast<int32_t*>(&rax3) = -1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f88 >= rdi->f96->f88)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = -1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

int64_t fun_100001192(struct s42* rdi, struct s44* rsi) {
    int64_t rax3;

    *reinterpret_cast<int32_t*>(&rax3) = -1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
    if (rsi->f96->f80 <= rdi->f96->f80) {
        if (rsi->f96->f80 >= rdi->f96->f80) {
            if (rsi->f96->f88 <= rdi->f96->f88 && (*reinterpret_cast<int32_t*>(&rax3) = 1, *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0, rsi->f96->f88 >= rdi->f96->f88)) {
                goto 0x100004594;
            }
        } else {
            *reinterpret_cast<int32_t*>(&rax3) = 1;
            *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax3) + 4) = 0;
        }
    }
    return rax3;
}

void fun_1000011e0(int64_t rdi, struct s0* rsi, struct s0* rdx) {
    struct s0* rsi4;
    int32_t eax5;
    struct s0* rdi6;
    struct s0* rax7;
    uint32_t eax8;
    struct s0* rax9;
    int32_t eax10;
    uint32_t eax11;
    uint16_t v12;
    int32_t eax13;

    if (reinterpret_cast<uint1_t>(reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&rdi) < 0) | reinterpret_cast<uint1_t>(*reinterpret_cast<int32_t*>(&rdi) == 0))) {
        fun_1000043f1(rdi, rsi, rdx);
    }
    rsi4 = reinterpret_cast<struct s0*>(0x100004ae8);
    _setlocale();
    eax5 = _isatty(1, 0x100004ae8, rdx);
    if (!eax5) {
        g100005500 = 1;
        rdi6 = reinterpret_cast<struct s0*>(0x100004ae9);
        rax7 = _getenv(0x100004ae9, 0x100004ae8, rdx);
        if (rax7) {
            rdi6 = rax7;
            eax8 = _atoi(rdi6, 0x100004ae8);
            g1000054d0 = eax8;
        }
    } else {
        g1000054d0 = 80;
        rax9 = _getenv(0x100004ae9, 0x100004ae8, rdx);
        if (!rax9 || !*reinterpret_cast<struct s0**>(&rax9->f0)) {
            rdx = reinterpret_cast<struct s0*>(reinterpret_cast<int64_t>(__zero_stack_offset()) - 8 + 0xffffffffffffffd0);
            *reinterpret_cast<int32_t*>(&rdi6) = 1;
            *reinterpret_cast<int32_t*>(&rdi6 + 4) = 0;
            *reinterpret_cast<int32_t*>(&rsi4) = 0x40087468;
            *reinterpret_cast<int32_t*>(&rsi4 + 4) = 0;
            eax10 = _ioctl(1, 0x40087468, rdx);
            if (eax10 == -1 || (eax11 = static_cast<uint32_t>(v12), eax11 == 0)) {
                addr_0x100001280_8:
                g100005634 = 1;
            } else {
                addr_0x10000127a_9:
                g1000054d0 = eax11;
                goto addr_0x100001280_8;
            }
        } else {
            rdi6 = rax9;
            eax11 = _atoi(rdi6, 0x100004ae8);
            goto addr_0x10000127a_9;
        }
    }
    eax13 = _getuid(rdi6, rsi4, rdx);
    if (eax13) 
        goto 0x1000012db;
    g100005504 = 1;
    goto 0x1000012db;
}

void fun_100001320() {
    g100005664 = 1;
    g100005654 = 0;
    goto 0x1000012db;
}

void fun_1000013ce() {
    g100005514 = 1;
    goto 0x1000012db;
}

void fun_10000143a() {
    g100005520 = 1;
    goto 0x1000012db;
}

void fun_100001536() {
    g100005508 = 1;
    goto 0x1000012db;
}

void fun_1000028e5(int32_t edi) {
}

uint32_t g1000054f0 = 0xffffffff;

struct s5** g100005540 = reinterpret_cast<struct s5**>(0);

uint32_t g100005658 = 0;

struct s5* fun_10000372d(struct s55* rdi) {
    struct s55* rbx2;
    struct s55* v3;
    int1_t zf4;
    int64_t r14_5;
    uint32_t ecx6;
    struct s5** rdi7;
    struct s5** rax8;
    struct s5** rdi9;
    struct s5* rax10;
    uint32_t v11;
    int64_t rcx12;
    struct s5** rdx13;
    uint64_t rax14;
    uint64_t rdx15;
    int1_t zf16;
    int64_t rcx17;
    uint32_t ecx18;
    int32_t r15d19;
    int1_t zf20;
    uint32_t eax21;
    uint32_t v22;
    int64_t r15_23;
    uint32_t eax24;
    int32_t v25;
    uint32_t eax26;
    uint32_t v27;
    struct s5* rax28;
    int64_t v29;
    uint32_t ecx30;
    int64_t r14_31;
    int64_t v32;
    uint32_t edx33;
    uint32_t r15d34;
    int64_t rbx35;
    uint32_t eax36;
    int1_t zf37;
    int64_t r13_38;
    uint32_t v39;
    int32_t r12d40;
    uint32_t ecx41;
    struct s5** rcx42;
    struct s5* rdi43;
    struct s0* rdx44;
    struct s0* rsi45;
    struct s5* rax46;
    uint32_t r15d47;
    uint32_t r13d48;
    uint32_t v49;
    int1_t zf50;

    rbx2 = rdi;
    v3 = rbx2;
    zf4 = g100005638 == 0;
    *reinterpret_cast<int32_t*>(&r14_5) = 1;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r14_5) + 4) = 0;
    if (zf4) {
        *reinterpret_cast<int32_t*>(&r14_5) = 8;
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r14_5) + 4) = 0;
    }
    ecx6 = g1000054f0;
    if (ecx6 == 0xffffffff || reinterpret_cast<int32_t>(rbx2->f20) > reinterpret_cast<int32_t>(ecx6)) {
        g1000054f0 = rbx2->f20;
        rdi7 = g100005540;
        rax8 = _realloc(rdi7);
        rdi9 = rax8;
        g100005540 = rdi9;
        if (!rdi9) {
            _warn();
            goto addr_0x1000039f9_6;
        }
    } else {
        rdi9 = g100005540;
    }
    ___bzero(rdi9);
    rax10 = rbx2->f0;
    v11 = 0;
    while (rax10) {
        if (rax10->f24 != 1) {
            rcx12 = static_cast<int64_t>(reinterpret_cast<int32_t>(v11));
            ++v11;
            rdx13 = g100005540;
            rdx13[rcx12] = rax10;
        }
        rax10 = rax10->f16;
    }
    rax14 = rbx2->f24;
    rdx15 = rax14 >> 32;
    zf16 = g10000562c == 0;
    if (!zf16) {
        *reinterpret_cast<int32_t*>(&rcx17) = rbx2->f44;
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rcx17) + 4) = 0;
        *reinterpret_cast<int32_t*>(&rax14) = static_cast<int32_t>(rax14 + rcx17 + 1);
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rax14) + 4) = 0;
    }
    ecx18 = g100005650;
    r15d19 = static_cast<int32_t>(rax14 + rdx15 + 1);
    if (!ecx18) {
        r15d19 = *reinterpret_cast<int32_t*>(&rax14);
    }
    zf20 = g100005664 == 0;
    eax21 = reinterpret_cast<uint32_t>(-*reinterpret_cast<int32_t*>(&r14_5));
    v22 = eax21;
    *reinterpret_cast<uint32_t*>(&r15_23) = r15d19 + *reinterpret_cast<int32_t*>(&r14_5) + static_cast<unsigned char>(reinterpret_cast<uint1_t>(!zf20)) & eax21;
    *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&r15_23) + 4) = 0;
    eax24 = g1000054d0;
    if (reinterpret_cast<int32_t>(eax24) < reinterpret_cast<int32_t>(static_cast<uint32_t>(r15_23 + r15_23))) {
        addr_0x1000039f9_6:
        goto 0x1000028ec;
    } else {
        __asm__("cdq ");
        v25 = reinterpret_cast<int32_t>(eax24) / reinterpret_cast<int32_t>(*reinterpret_cast<uint32_t*>(&r15_23));
        __asm__("cdq ");
        eax26 = reinterpret_cast<uint32_t>(reinterpret_cast<int32_t>(v11) / (reinterpret_cast<int32_t>(eax24) / reinterpret_cast<int32_t>(*reinterpret_cast<uint32_t*>(&r15_23))));
        v27 = eax26 - (1 - reinterpret_cast<uint1_t>(eax26 < 1 - reinterpret_cast<uint1_t>(reinterpret_cast<uint32_t>(reinterpret_cast<int32_t>(v11) % (reinterpret_cast<int32_t>(eax24) / reinterpret_cast<int32_t>(*reinterpret_cast<uint32_t*>(&r15_23)))) < 1)));
        rax28 = rbx2->f0;
        if (!rax28) {
            addr_0x100003a2e_20:
            ___assert_rtn("printcol", "/BuildRoot/Library/Caches/com.apple.xbs/Sources/file_cmds/file_cmds-264.30.2/ls/print.c", 0x20a, "dp->list");
        } else {
            v29 = r14_5;
            if (rax28->f86 && (rax28 = reinterpret_cast<struct s5*>(0x100005630), ecx30 = ecx18 | g100005630, !!ecx30)) {
                rax28 = _printf(0x100004c73, 0x100004c73);
            }
            r14_31 = r15_23;
            v32 = r14_31;
            if (reinterpret_cast<int32_t>(v27) > reinterpret_cast<int32_t>(0)) {
                edx33 = 0;
                r15d34 = 0;
                goto addr_0x1000038cd_25;
            }
        }
    }
    addr_0x1000039e1_26:
    return rax28;
    addr_0x100003a0f_27:
    ___assert_rtn("printcol", "/BuildRoot/Library/Caches/com.apple.xbs/Sources/file_cmds/file_cmds-264.30.2/ls/print.c", 0x214, "base < dp->entries");
    goto addr_0x100003a2e_20;
    while (1) {
        *reinterpret_cast<uint32_t*>(&rbx35) = eax36;
        *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rbx35) + 4) = 0;
        zf37 = g100005638 == 0;
        if (!zf37) {
        }
        _putchar();
        eax36 = static_cast<uint32_t>(rbx35 + r13_38) & v22;
        if (reinterpret_cast<int32_t>(eax36) > reinterpret_cast<int32_t>(v39)) 
            goto addr_0x1000039a6_31;
        if (r12d40 < v25) 
            continue;
        ecx41 = g100005658;
        goto addr_0x10000396d_34;
        while (1) {
            if (reinterpret_cast<int32_t>(r15d34) >= reinterpret_cast<int32_t>(rbx2->f20)) 
                goto addr_0x100003a0f_27;
            rcx42 = g100005540;
            rdi43 = rcx42[r15d34];
            *reinterpret_cast<int32_t*>(&rdx44) = *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(rbx2) + 28);
            *reinterpret_cast<int32_t*>(&rdx44 + 4) = 0;
            *reinterpret_cast<int32_t*>(&rsi45) = rbx2->f44;
            *reinterpret_cast<int32_t*>(&rsi45 + 4) = 0;
            rax46 = fun_1000029ba(rdi43, rsi45, rdx44);
            ecx41 = g100005658;
            r15d47 = 1;
            if (!ecx41) {
                r15d47 = v27;
            }
            r15d34 = r15d47 + r15d34;
            if (reinterpret_cast<int32_t>(r15d34) >= reinterpret_cast<int32_t>(v11)) {
                rbx2 = v3;
                r14_31 = v32;
            } else {
                *reinterpret_cast<uint32_t*>(&rbx35) = *reinterpret_cast<int32_t*>(&rax46) + r13d48;
                *reinterpret_cast<int32_t*>(reinterpret_cast<int64_t>(&rbx35) + 4) = 0;
                r13_38 = v29;
                eax36 = static_cast<uint32_t>(rbx35 + r13_38) & v22;
                ++r12d40;
                if (reinterpret_cast<int32_t>(eax36) <= reinterpret_cast<int32_t>(v39)) {
                    if (r12d40 < v25) 
                        break;
                    addr_0x10000396d_34:
                    if (!ecx41) 
                        break;
                }
                addr_0x1000039a6_31:
                r14_31 = v32;
                v39 = v39 + *reinterpret_cast<uint32_t*>(&r14_31);
                r13d48 = *reinterpret_cast<uint32_t*>(&rbx35);
                rbx2 = v3;
                if (r12d40 < v25) 
                    continue;
            }
            do {
                rax28 = _putchar();
                edx33 = v49 + 1;
                if (reinterpret_cast<int32_t>(edx33) >= reinterpret_cast<int32_t>(v27)) 
                    goto addr_0x1000039e1_26;
                addr_0x1000038cd_25:
                v49 = edx33;
                zf50 = g100005658 == 0;
                if (zf50) {
                    r15d34 = edx33;
                }
                v39 = *reinterpret_cast<uint32_t*>(&r14_31);
                r12d40 = 0;
                r13d48 = 0;
            } while (v25 <= 0);
        }
    }
}

int64_t fun_100003c69() {
    _putchar();
    return 0;
}

void fun_100001336() {
    _setenv("CLICOLOR", 0x100004ae8, 1);
    goto 0x1000012db;
}

void fun_100001610() {
    g100005654 = 1;
    g100005664 = 1;
    goto 0x1000012db;
}

void fun_1000013da() {
    g100005660 = 1;
    g100005500 = 0;
    g100005630 = 0;
    goto 0x1000012db;
}

void fun_100001446() {
    g100005610 = 1;
    g100005618 = 0;
    g10000565c = 0;
    goto 0x1000012db;
}

void fun_100001542() {
    g10000551c = 1;
    goto 0x1000012db;
}

void fun_100001350() {
    g100005634 = 0;
    g100005640 = 0;
    g100005644 = 1;
    goto 0x1000012db;
}

void fun_100001626() {
    g100005634 = 1;
    g100005640 = 0;
    g100005644 = 0;
    goto 0x1000012db;
}

void fun_1000013fa() {
    struct s0* rdx1;
    unsigned char al2;

    g10000563c = 1;
    al2 = _compat_mode("bin/ls", 0x100004b20, rdx1);
    if (!al2) 
        goto 0x1000012db;
    g100005630 = 1;
    goto 0x1000012ca;
}

void fun_100001463() {
    g100005658 = 1;
    g100005630 = 0;
    g100005500 = 0;
    goto 0x1000012db;
}

void fun_10000154e() {
    g10000564c = 1;
    goto 0x1000012db;
}

int64_t dyld_stub_binder = 0;

void fun_1000045f8() {
    goto dyld_stub_binder;
}

void fun_10000136d() {
    struct s0* rdx1;
    unsigned char al2;

    g100005510 = 1;
    al2 = _compat_mode("bin/ls", 0x100004b20, rdx1);
    if (!al2) 
        goto 0x1000012db;
    goto 0x1000012c1;
}

void fun_100001634() {
    g100005650 = 1;
    goto 0x1000012db;
}

void fun_100001483() {
    g100005668 = 1;
    goto 0x1000012db;
}

void fun_10000155d() {
    g100005618 = 1;
    g100005610 = 0;
    g10000565c = 0;
    goto 0x1000012db;
}

void fun_100004602() {
    goto 0x1000045e8;
}

void fun_100001643() {
    g100005634 = 0;
    goto 0x1000012db;
}

void fun_100001492() {
    g100005634 = 0;
    g100005640 = 1;
    g100005644 = 0;
    goto 0x1000012db;
}

void fun_10000157a() {
    g100005524 = 1;
    goto 0x1000012db;
}

void fun_10000460c() {
    goto 0x1000045e8;
}

void fun_100001652() {
    g100005634 = 0;
}

void fun_1000014af() {
    g100005500 = 0;
    g100005630 = 0;
    g100005658 = 0;
    goto 0x1000012db;
}

void fun_100001586() {
    g10000565c = 1;
    g100005618 = 0;
    g100005610 = 0;
    goto 0x1000012db;
}

void fun_100004616() {
    goto 0x1000045e8;
}

void fun_1000014c9() {
    struct s0* rdx1;
    unsigned char al2;

    al2 = _compat_mode("bin/ls", 0x100004b20, rdx1);
    if (!al2) {
        goto 0x1000012db;
    } else {
        goto 0x1000012db;
    }
}

void fun_1000015a3() {
    g10000550c = 1;
    g100005508 = 0;
    goto 0x1000012db;
}

void fun_100004620() {
    goto 0x1000045e8;
}

void fun_1000015b6() {
    g100005614 = 1;
    goto 0x1000012db;
}

void fun_10000462a() {
    goto 0x1000045e8;
}

void fun_1000015c5() {
    g10000562c = 1;
    goto 0x1000012db;
}

void fun_100004634() {
    goto 0x1000045e8;
}

void fun_1000015d4() {
    struct s0* rdx1;
    unsigned char al2;

    al2 = _compat_mode("bin/ls", 0x100004b20, rdx1);
    if (!al2) {
        g100005620 = 1;
        goto 0x1000012db;
    } else {
        g100005648 = 1;
    }
}

void fun_10000463e() {
    goto 0x1000045e8;
}

void fun_100004648() {
    goto 0x1000045e8;
}

void fun_100004652() {
    goto 0x1000045e8;
}

void fun_10000465c() {
    goto 0x1000045e8;
}

void fun_100004666() {
    goto 0x1000045e8;
}

void fun_100004670() {
    goto 0x1000045e8;
}

void fun_10000467a() {
    goto 0x1000045e8;
}

void fun_100004684() {
    goto 0x1000045e8;
}

void fun_10000468e() {
    goto 0x1000045e8;
}

void fun_100004698() {
    goto 0x1000045e8;
}

void fun_1000046a2() {
    goto 0x1000045e8;
}

void fun_1000046ac() {
    goto 0x1000045e8;
}

void fun_1000046b6() {
    goto 0x1000045e8;
}

void fun_1000046c0() {
    goto 0x1000045e8;
}

void fun_1000046ca() {
    goto 0x1000045e8;
}

void fun_1000046d4() {
    goto 0x1000045e8;
}

void fun_1000046de() {
    goto 0x1000045e8;
}

void fun_1000046e8() {
    goto 0x1000045e8;
}

void fun_1000046f2() {
    goto 0x1000045e8;
}

void fun_1000046fc() {
    goto 0x1000045e8;
}

void fun_100004706() {
    goto 0x1000045e8;
}

void fun_100004710() {
    goto 0x1000045e8;
}

void fun_10000471a() {
    goto 0x1000045e8;
}

void fun_100004724() {
    goto 0x1000045e8;
}

void fun_10000472e() {
    goto 0x1000045e8;
}

void fun_100004738() {
    goto 0x1000045e8;
}

void fun_100004742() {
    goto 0x1000045e8;
}

void fun_10000474c() {
    goto 0x1000045e8;
}

void fun_100004756() {
    goto 0x1000045e8;
}

void fun_100004760() {
    goto 0x1000045e8;
}

void fun_10000476a() {
    goto 0x1000045e8;
}

void fun_100004774() {
    goto 0x1000045e8;
}

void fun_10000477e() {
    goto 0x1000045e8;
}

void fun_100004788() {
    goto 0x1000045e8;
}

void fun_100004792() {
    goto 0x1000045e8;
}

void fun_10000479c() {
    goto 0x1000045e8;
}

void fun_1000047a6() {
    goto 0x1000045e8;
}

void fun_1000047b0() {
    goto 0x1000045e8;
}

void fun_1000047ba() {
    goto 0x1000045e8;
}

void fun_1000047c4() {
    goto 0x1000045e8;
}

void fun_1000047ce() {
    goto 0x1000045e8;
}

void fun_1000047d8() {
    goto 0x1000045e8;
}

void fun_1000047e2() {
    goto 0x1000045e8;
}

void fun_1000047ec() {
    goto 0x1000045e8;
}

void fun_1000047f6() {
    goto 0x1000045e8;
}

void fun_100004800() {
    goto 0x1000045e8;
}

void fun_10000480a() {
    goto 0x1000045e8;
}

void fun_100004814() {
    goto 0x1000045e8;
}

void fun_10000481e() {
    goto 0x1000045e8;
}

void fun_100004828() {
    goto 0x1000045e8;
}

void fun_100004832() {
    goto 0x1000045e8;
}

void fun_10000483c() {
    goto 0x1000045e8;
}

void fun_100004846() {
    goto 0x1000045e8;
}

void fun_100004850() {
    goto 0x1000045e8;
}

void fun_10000485a() {
    goto 0x1000045e8;
}

void fun_100004864() {
    goto 0x1000045e8;
}

void fun_10000486e() {
    goto 0x1000045e8;
}

void fun_100004878() {
    goto 0x1000045e8;
}

void fun_100004882() {
    goto 0x1000045e8;
}

void fun_10000488c() {
    goto 0x1000045e8;
}

void fun_100004896() {
    goto 0x1000045e8;
}

void fun_1000048a0() {
    goto 0x1000045e8;
}

void fun_1000048aa() {
    goto 0x1000045e8;
}

void fun_1000048b4() {
    goto 0x1000045e8;
}

void fun_1000048be() {
    goto 0x1000045e8;
}

void fun_1000048c8() {
    goto 0x1000045e8;
}

void fun_1000048d2() {
    goto 0x1000045e8;
}

void fun_1000048dc() {
    goto 0x1000045e8;
}

void fun_1000048e6() {
    goto 0x1000045e8;
}

