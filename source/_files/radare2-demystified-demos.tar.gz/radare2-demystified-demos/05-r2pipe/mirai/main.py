import mirai

a = mirai.get_config("1fce697993690d41f75e0e6ed522df49d73a038f7e02733ec239c835579c40bf")
print a
