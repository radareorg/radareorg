#!/usr/bin/env python

import os
import sys
import string
import r2pipe

def decrypt(data,key):
    xor=lambda x ,y :int(x,16)^int(y,16)
    ans=""
    for temp in [data[a:a+2] for a in range(0,len(data)-2,2)]:
        ans=ans+chr(xor(temp,key))
    return ans

def simplify_xor(xorkey_offset):
    simplify_xor = 0
    for xorsub in [xorkey_offset[i:i+2] for i in range(0, len(xorkey_offset), 2)]:
        simplify_xor =  simplify_xor ^ int(xorsub, 16)
    return simplify_xor 

def get_config(malwareFile):
    r2 = r2pipe.open(malwareFile)
    r2.cmd("e! asm.xrefs")
    r2.cmd("aaa")
    r2.cmd("zn miraiB")
    r2.cmd("zb decryptAuthTable f0......80......07......80......b4......a0......03......06..............f0......a0......04..............04......01......22......03......22......ff......ff......22......ff......17......................02......03......02..............01......03......01..............02......03......02..............01......03......01......04......01......01......03......0c......e9......06......01..............06......f0......")
    r2.cmd("zn-")
    r2.cmd(".z/")
    r2.cmd("s sign.miraiB.b.decryptAuthTable")
    xorptr_offset = str(r2.cmdj("aoj 1 @i:10")[0]["ptr"])
    xorkey_offset = str(r2.cmd("pv4 @" + xorptr_offset))
    xorkey = r2.cmd("p8 4 @ " + xorkey_offset)
    print "\nThe xorkey is %s" % xorkey
    xorkey = simplify_xor(xorkey)
    print "The simplified xorkey is %s" % hex(xorkey)
    size_xored_data = r2.cmd("? str.Unknown_error - str.abcdefghijklmnopqrstuvw012345678")
    strin = r2.cmd("p8 " + size_xored_data + " @ str.abcdefghijklmnopqrstuvw012345678 + 0x00000021")
    dexor = decrypt(strin,hex(xorkey))
    return ''.join([i if ord(i) < 128 else ' ' for i in dexor])

def main():
    print get_config(os.environ.get('R2_FILE'))
    pass

if __name__ == "__main__":
    main()

