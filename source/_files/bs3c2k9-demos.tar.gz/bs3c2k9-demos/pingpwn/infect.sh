#!/bin/sh
cat <<_EOF_
e asm.profile=simple
e scr.color=0
f len @ section._text_end-section._text
s section._text
fN hackpoint @@=\`pD len~imp.strncpy[0]\`
.af* @@=\`pD len~call[3]\`
e search.from = section._text
e search.to = section._text_end
e cmd.hit=.af*
/x 55 89 e5
fs*
e cmd.hit
e scr.color=1
_EOF_

