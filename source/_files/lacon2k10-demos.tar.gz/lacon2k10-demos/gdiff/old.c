#include <string.h>

void foo (char *str) {
	char buf[256];
	if (str != NULL)
		strcpy (buf, str);
}

int main(int argc, char **argv) {
	foo(argv[1]);
	return 0;
} 
