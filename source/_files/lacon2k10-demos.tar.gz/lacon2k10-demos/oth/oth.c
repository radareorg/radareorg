/* oth.c - lacon'10 - nibble<develsec.org> */

#include <stdio.h>
#include <string.h>
#include <r_asm.h>
#include <r_bin.h>
#include <r_anal.h>
#include <r_list.h>
#include <r_util.h>

#define MAX_ENTRY_SZ 1024
#define JMP_SZ 6
#define RET_SZ 1

int main(int argc, char **argv) {
	RBin *bin;
	RBinAddr *entry;
	RBinImport *imp;
	RBinReloc *rel;
	RAsm *a;
	RAsmCode *acode;
	RAnal *anal;
	RAnalOp *aop;
	RListIter *iter;
	ut8 *bytes;
	ut64 entry_va = -1, entry_off = -1, entry_sz = -1;
	ut64 init_va = -1, init_off = -1, libc_main_va = -1;
	ut64 import_va = -1, rel_va = -1, rel_off = -1;
	ut64 baddr, i = 0;
	ut64 args[64];
	ut32 payload_va;
	char *file, *import, *code;
	int oplen, j = 0;

	/* Parse args */
	if (argc != 3) {
		fprintf (stderr, "Usage: %s <bin file> <import>\n", argv[0]);
		return 1;
	}
	file = argv[1];
	import = argv[2];

	/* Init resources */
	bin = r_bin_new ();
	a = r_asm_new ();
	r_asm_use (a, "x86.olly");
	r_asm_set_bits (a, 32);
	anal = r_anal_new ();
	aop = r_anal_aop_new ();
	r_anal_use (anal, "x86");
	r_anal_set_bits (anal, 32);

	/* Load and analyze bin */
	if (!r_bin_load (bin, argv[1], R_FALSE)) {
		fprintf (stderr, "Cannot open file '%s'\n", file);
		return 1;
	}

	/* Get the offset and va of the entrypoint */
	baddr = r_bin_get_baddr (bin);
	r_list_foreach (r_bin_get_entries (bin), iter, entry) {
		entry_va = baddr + entry->rva;
		entry_off = entry->offset;
		break;
	}

	if (entry_va == -1 || entry_off == -1) {
		fprintf (stderr, "Error: Cannot find entrypoint\n");
		return 1;
	}

	/* Resolve the va of __libc_start_main */
	r_list_foreach (r_bin_get_imports (bin), iter, imp)
		if (!strcmp (imp->name, "__libc_start_main")) {
			libc_main_va = baddr + imp->rva;
			break;
		}

	if (libc_main_va == -1) {
		fprintf (stderr, "Error: Cannot find __libc_star_main\n");
		return 1;
	}

	/* Analyze entrypoint a get the offset, va and size of init */
	bytes = malloc (MAX_ENTRY_SZ);
	r_buf_read_at (bin->curarch.buf, entry_off, bytes, MAX_ENTRY_SZ);
	while (i < MAX_ENTRY_SZ) {
		if ((oplen = r_anal_aop (anal, aop, entry_va+i, bytes+i, MAX_ENTRY_SZ-i)) == 0)
			break;
		i += oplen;
		if (aop->type == R_ANAL_OP_TYPE_PUSH) {
			args[j++] = aop->ref;
		} else if (aop->type == R_ANAL_OP_TYPE_CALL) {
			if (aop->jump == libc_main_va && j > 2) {
				init_va = args[j-2];
				init_off = init_va - baddr;
			}
		} else if (aop->type == R_ANAL_OP_TYPE_RET) {
			entry_sz = i;
			break;
		}
	}
	free (bytes);

	if (entry_sz == -1 || init_va == -1 || init_off == -1) {
		fprintf (stderr, "Error: Cannot analyze entrypoint\n");
		return 1;
	}

	/* Get the va of the target import */
	r_list_foreach (r_bin_get_imports (bin), iter, imp)
		if (!strcmp (imp->name, import))
			import_va = baddr + imp->rva;

	/* Get the reloc info of the target import */
	r_list_foreach (r_bin_get_relocs (bin), iter, rel)
		if (!strcmp (rel->name, import)) {
			rel_va = baddr + rel->rva;
			rel_off = rel->offset;
			break;
		}

	if (import_va == -1 || rel_va == -1 || rel_off == -1) {
		fprintf (stderr, "Error: Cannot find import '%s'\n", import);
		return 1;
	}

	/* Overwrite the got entry of the given import with payload address */
	payload_va = init_va + RET_SZ;
	r_buf_write_at (bin->curarch.buf, rel_off, (ut8*)&payload_va, sizeof (ut32));

	/* Assemble the hook handler and write it into init */
	r_asm_set_pc (a, init_va);
	code = r_str_dup_printf (
			"ret;"
			"mov dword [esp+4], 0x1337;"
			"jmp 0x%08llx", import_va + JMP_SZ);
	acode = r_asm_massemble(a, code);
	r_buf_write_at (bin->curarch.buf, init_off, acode->buf, acode->len);
	free (code);

	/* Output patched bin */
	r_bin_wr_output (bin, "a.out");

	/* Free resources */
	r_anal_aop_free (aop);
	r_anal_free (anal);
	r_asm_code_free (acode);
	r_asm_free (a);
	r_bin_free (bin);

	return 0;
}
