import r2pipe

r2 = r2pipe.open("./crackme")
r2.cmd("s sym._checkPassword")
r2.cmd("aeim;aes")
r2.cmd("dr rip=sym._checkPassword")
r2.cmd("aesu sym.imp.strcmp")
print r2.cmd("drr~rsi 0x").split(' ')[-1]
