#include <stdio.h>
void main() {
	printf(".\n");
	printf("Hello World\n");
}
